﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public static Form1 instance;
        public static int n_rounds = 0;
        public Form1()
        {
            InitializeComponent();
            instance = this;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (maskedTextBox1.Text.Length!=0 && maskedTextBox1.Text!="0")
            {
                n_rounds = Convert.ToInt32( maskedTextBox1.Text);
                Form form2 = new Form2();
                form2.Show();
                
            }
            else
                MessageBox.Show("Please Enter Number of Rounds ", "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
       //private bool ValidationText(string text)
       // {
       //     for (int i = 0; i < text.Length; i++)
       //     {
       //         if (Char.IsLetter(text[i]))
       //         {
       //             return true;
       //         }
       //     }
       //     return false;
       // }
        private void Form1_Load(object sender, EventArgs e)
        {
            lbName.BackColor=Color.FromArgb(102,128,153);
        }
    }
}
