﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
       
        private Image image_Player, image_computer;
        public static short score_player = 0, score_computer = 0, NoWiner = 0;
        private short your_choice=0 , computer_choice=0;
        public static int n_rounds = 0;
        private string winer = " "; // the winer in each round
        public Form2()
        {
            InitializeComponent();
            
          
        }

        private void Form2_Load(object sender, EventArgs e)
        {
          n_rounds=  Form1.n_rounds ;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            n_rounds--;
            your_choice = 1;
            pictureBox1.Image = selected_image(your_choice);
            GetCompChoice();
            pictureBox2.Image = selected_image(computer_choice);
            TheWiner();
            end_game( n_rounds);
        }

        private void btPaper_Click(object sender, EventArgs e)
        {
            n_rounds--;
            your_choice = 2;
            pictureBox1.Image = selected_image(your_choice);
            GetCompChoice();
            pictureBox2.Image = selected_image(computer_choice);
            TheWiner();
            end_game( n_rounds);
        }

        private void btScissors_Click(object sender, EventArgs e)
        {
            n_rounds--;

            your_choice = 3;
           
            pictureBox1.Image = selected_image(your_choice);
            GetCompChoice();
            pictureBox2.Image = selected_image(computer_choice);
            TheWiner();
            end_game( n_rounds);
        }
        private void end_game(int n_rounds)
        {
            if (n_rounds == 0)
            {
                Form form = new Form3();
                form.ShowDialog();
                this.Close();
            }
        }
        private Image selected_image(short choice)
        {
            Image image =null;
            switch (choice)
            {
                    case 1:
                    image = Properties.Resources.rock;
                    break;
                    case 2:
                    image = Properties.Resources.paper;
                    break;
                    case 3:
                    image = Properties.Resources.scissors;
                    break;
                    
            }
                return image;

        }
        private void GetCompChoice()
        {
            Random random = new Random();
            computer_choice = (short)random.Next(1, 3);
        }
        // 1 represent about stone
        // 2 represent about paper
        // 3 represent about scissors
       private void TheWiner( )
        {
            if ((your_choice == 2) && (computer_choice == 3))
            {
                winer = " The Computer ";
                score_computer++;
            }

            else if ((your_choice == 1) && (computer_choice == 2))
            {
                winer = " The Computer ";
                
                score_computer++;
            }
            else if ((your_choice == 2) && (computer_choice == 1))
            {
                winer = " The Player ";
                score_player++;
            }
            else if ((your_choice == 3) && (computer_choice == 1))
            {
                winer = " The Computer ";
                
                score_computer++;
            }
            else if ((your_choice == 3) && (computer_choice == 2))
            {
                winer = " The Player ";
                score_player++;
            }
            else if ((your_choice == 1) && (computer_choice == 3))
            {
                winer = " The Player ";
                score_player++;
            }
            else
            {
                winer = " No Winer ";
                NoWiner++;
            }
            lbComp_Count.Text = score_computer.ToString();
            lbPlayer_Count.Text = score_player.ToString();
            label3.Text = winer+"Wins";
        }
    }
}
