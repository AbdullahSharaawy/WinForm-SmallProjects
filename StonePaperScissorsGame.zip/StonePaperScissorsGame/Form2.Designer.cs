﻿namespace WindowsFormsApp1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbPlayer_Count = new System.Windows.Forms.Label();
            this.lbComp_Count = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btRock = new System.Windows.Forms.Button();
            this.btPaper = new System.Windows.Forms.Button();
            this.btScissors = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(86, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Player";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(582, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(141, 31);
            this.label2.TabIndex = 1;
            this.label2.Text = "Computer";
            // 
            // lbPlayer_Count
            // 
            this.lbPlayer_Count.AutoSize = true;
            this.lbPlayer_Count.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPlayer_Count.Location = new System.Drawing.Point(115, 54);
            this.lbPlayer_Count.Name = "lbPlayer_Count";
            this.lbPlayer_Count.Size = new System.Drawing.Size(30, 31);
            this.lbPlayer_Count.TabIndex = 2;
            this.lbPlayer_Count.Text = "0";
            // 
            // lbComp_Count
            // 
            this.lbComp_Count.AutoSize = true;
            this.lbComp_Count.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbComp_Count.Location = new System.Drawing.Point(646, 54);
            this.lbComp_Count.Name = "lbComp_Count";
            this.lbComp_Count.Size = new System.Drawing.Size(30, 31);
            this.lbComp_Count.TabIndex = 3;
            this.lbComp_Count.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Cooper Black", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(264, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(297, 36);
            this.label3.TabIndex = 4;
            this.label3.Text = "Choose an Option";
            // 
            // btRock
            // 
            this.btRock.BackColor = System.Drawing.Color.DarkCyan;
            this.btRock.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btRock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btRock.ForeColor = System.Drawing.Color.White;
            this.btRock.Location = new System.Drawing.Point(173, 355);
            this.btRock.Name = "btRock";
            this.btRock.Size = new System.Drawing.Size(127, 40);
            this.btRock.TabIndex = 5;
            this.btRock.Text = "Rock";
            this.btRock.UseVisualStyleBackColor = false;
            this.btRock.Click += new System.EventHandler(this.button1_Click);
            // 
            // btPaper
            // 
            this.btPaper.BackColor = System.Drawing.Color.DarkCyan;
            this.btPaper.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btPaper.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btPaper.ForeColor = System.Drawing.Color.White;
            this.btPaper.Location = new System.Drawing.Point(350, 355);
            this.btPaper.Name = "btPaper";
            this.btPaper.Size = new System.Drawing.Size(127, 40);
            this.btPaper.TabIndex = 6;
            this.btPaper.Text = "Paper";
            this.btPaper.UseVisualStyleBackColor = false;
            this.btPaper.Click += new System.EventHandler(this.btPaper_Click);
            // 
            // btScissors
            // 
            this.btScissors.BackColor = System.Drawing.Color.DarkCyan;
            this.btScissors.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btScissors.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btScissors.ForeColor = System.Drawing.Color.White;
            this.btScissors.Location = new System.Drawing.Point(527, 355);
            this.btScissors.Name = "btScissors";
            this.btScissors.Size = new System.Drawing.Size(127, 40);
            this.btScissors.TabIndex = 7;
            this.btScissors.Text = "Scissors";
            this.btScissors.UseVisualStyleBackColor = false;
            this.btScissors.Click += new System.EventHandler(this.btScissors_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(173, 186);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(170, 123);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(484, 186);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(170, 123);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btScissors);
            this.Controls.Add(this.btPaper);
            this.Controls.Add(this.btRock);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbComp_Count);
            this.Controls.Add(this.lbPlayer_Count);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbPlayer_Count;
        private System.Windows.Forms.Label lbComp_Count;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btRock;
        private System.Windows.Forms.Button btPaper;
        private System.Windows.Forms.Button btScissors;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}