﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{

    public partial class Form3 : Form
    {

        private short score_player = 0, score_computer = 0, NoWiner = 0;
        private int n_rounds = 0;
        private string winer = null; // final result

       
        public Form3()
        {
            InitializeComponent();
            NoWiner=  Form2.NoWiner;
            score_computer=Form2.score_computer;
            score_player= Form2.score_player;
            n_rounds = Form2.n_rounds;
            label1.Text="Game Rounds: "+ n_rounds.ToString();
            label2.Text="Player won times "+score_player.ToString();
            label3.Text="computer won times "+score_computer.ToString();
            label4.Text= "Draw times "+NoWiner.ToString();
            winer = FinalResult();
            label5.Text = "Final Winer: " + winer;
            label1.BackColor = Color.FromArgb(125, Color.Black);
            label2.BackColor = Color.FromArgb(125, Color.Black);
            label3.BackColor = Color.FromArgb(125, Color.Black);
            label4.BackColor = Color.FromArgb(125, Color.Black);
            label5.BackColor = Color.FromArgb(125, Color.Black);

        }

       private string FinalResult( )
        {
            string Winer;
            if (score_computer > score_player) { Winer = "Computer Wins"; }

            else if (score_computer < score_player) { Winer = "Player Wins"; }

            else 
                Winer = "No Winer "; 
            
            return Winer;
        }
    }
}
