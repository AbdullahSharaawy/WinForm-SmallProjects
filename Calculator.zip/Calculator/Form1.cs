﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form

    {
        private double result = 0;
        private short sign = 1;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.ForeColor = Color.White;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Color green = Color.FromArgb(255, 0, 150, 0);
            Color blue = Color.FromArgb(255, 0, 0, 150);
            Color brown = Color.FromArgb(255, 10, 10, 10);

            Pen Pen1 = new Pen(green);
            Pen1.Width = 30;

            Pen Pen2 = new Pen(blue);
            Pen2.Width = 30;

            Pen Pen3 = new Pen(brown);
            Pen3.Width = 30;

            Pen1.StartCap = System.Drawing.Drawing2D.LineCap.Round;
            Pen1.EndCap = System.Drawing.Drawing2D.LineCap.Round;

            // Draw Circle vertical
            //Ac
            e.Graphics.DrawEllipse(Pen1, 30, 100, 30, 30);
            //()
            e.Graphics.DrawEllipse(Pen2, 110, 100, 30, 30);
            //%
            e.Graphics.DrawEllipse(Pen2, 190, 100, 30, 30);
            // /
            e.Graphics.DrawEllipse(Pen2, 270, 100, 30, 30);
            // *
            e.Graphics.DrawEllipse(Pen2, 270, 180, 30, 30);
            // -
            e.Graphics.DrawEllipse(Pen2, 270, 260, 30, 30);
            // +
            e.Graphics.DrawEllipse(Pen2, 270, 340, 30, 30);
            // =
            e.Graphics.DrawEllipse(Pen2, 270, 420, 30, 30);
            // 7
            e.Graphics.DrawEllipse(Pen3, 30, 180, 30, 30);
            // 4
            e.Graphics.DrawEllipse(Pen3, 30, 260, 30, 30);
            // 1
            e.Graphics.DrawEllipse(Pen3, 30, 340, 30, 30);
            // 0
            e.Graphics.DrawEllipse(Pen3, 30, 420, 30, 30);
            // 8
            e.Graphics.DrawEllipse(Pen3, 110, 180, 30, 30);
            // 5
            e.Graphics.DrawEllipse(Pen3, 110, 260, 30, 30);
            // 2
            e.Graphics.DrawEllipse(Pen3, 110, 340, 30, 30);
            // .
            e.Graphics.DrawEllipse(Pen3, 110, 420, 30, 30);
            // 9
            e.Graphics.DrawEllipse(Pen3, 190, 180, 30, 30);
            // 6
            e.Graphics.DrawEllipse(Pen3, 190, 260, 30, 30);
            // 3
            e.Graphics.DrawEllipse(Pen3, 190, 340, 30, 30);
            // delete
            e.Graphics.DrawEllipse(Pen3, 190, 420, 30, 30);

        }

        private void lb0_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length <= 11)
                textBox1.Text += '0';
            else lbequal_Click( sender,  e);
        }

        private void lbdot_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length <= 11 && !IsSympol(textBox1.Text.Last()) && textBox1.Text.Length != 0 && textBox1.Text.Last()!='.')
                textBox1.Text += '.';
            else lbequal_Click(sender, e);
        }

        private void lb1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length <= 11)
                textBox1.Text += '1';
            else lbequal_Click(sender, e);
        }

        private void lb2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length <= 11)
                textBox1.Text += '2';
            else lbequal_Click(sender, e);
        }





        private void lb7_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text.Length <= 11)
                textBox1.Text += '7';
            else lbequal_Click(sender, e);
        }

        private void lb3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length <= 11)
                textBox1.Text += '3';
            else lbequal_Click(sender, e);
        }

        private void lb4_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length <= 11)
                textBox1.Text += '4';
            else lbequal_Click(sender, e);
        }

        private void lb5_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length <= 11)
                textBox1.Text += '5';
            else lbequal_Click(sender, e);
        }

        private void lb6_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length <= 11)
                textBox1.Text += '6';
            else lbequal_Click(sender, e);
        }

        private void lb8_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length <= 11)
                textBox1.Text += '8';
            else lbequal_Click(sender, e);
        }

        private void lb9_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length <= 11)
                textBox1.Text += '9';
            else lbequal_Click(sender, e);
        }

        private void lbplus_Click(object sender, EventArgs e)
        {         
            if (textBox1.Text.Length < 11 && !IsSympol(textBox1.Text.Last()) && textBox1.Text.Length != 0)
                textBox1.Text += '+';
            else lbequal_Click(sender, e);
        }

        private void lbminus_Click(object sender, EventArgs e)
        {
             if(textBox1.Text.Length==0)
                textBox1.Text += '-';
          else  if ((textBox1.Text.Length < 11 && !IsSympol(textBox1.Text.Last())) )
                textBox1.Text += '-';
            
            else lbequal_Click(sender, e);
        }

        private void lbmulti_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length < 11 && !IsSympol(textBox1.Text.Last()) && textBox1.Text.Length != 0)
                textBox1.Text += '*';
            else lbequal_Click(sender, e);
        }

        private void lbdivision_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length < 11 && !IsSympol(textBox1.Text.Last()) && textBox1.Text.Length != 0)
                textBox1.Text += '/';
            else lbequal_Click(sender, e);
        }

        private void lbmod_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length < 11 && !IsSympol(textBox1.Text.Last()) && textBox1.Text.Length!=0)
                textBox1.Text += '%';
            else lbequal_Click(sender, e);
        }

        private void lbbracet_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text.Length < 8 && IsSympol(textBox1.Text.Last())) || textBox1.Text.Length == 0)
            {

                    textBox1.Text += '(';
                    return;
                
            }
            else if ((textBox1.Text.Length <=11 && !IsSympol(textBox1.Text.Last())) && textBox1.Text.Length != 0)
            {
                    textBox1.Text += ')';
                    return;
            }
            else lbequal_Click(sender, e);
        }
        private void Calc_InBracket()
        {
            if (textBox1.Text.Contains("(") && textBox1.Text.Contains(")"))
            {
                int start_index = 0, count;
                string Text = textBox1.Text;
                for (int i = 0; i < Text.Length; i++)
                {
                    if (textBox1.Text[i] == '(')
                    {
                        start_index = i;
                    }
                    if (textBox1.Text[i] == ')')
                    {
                        count = i - start_index;
                        textBox1.Text=textBox1.Text.Remove(start_index, count+1);
                        Text = Text.Substring(start_index + 1, count - 1);
                        Calculator(Text,true);
                        textBox1.Text=textBox1.Text.Insert(start_index, result.ToString());
                        break;
                    }
                }

            }
        else  if (textBox1.Text.Contains("(") || textBox1.Text.Contains(")"))
            {
                if(textBox1.Text.Contains("(") )
                {
                    int index=textBox1.Text.IndexOf("(");
                   textBox1.Text= textBox1.Text.Remove(index,1);
                }
                else if (textBox1.Text.Contains(")"))
                {
                    int index = textBox1.Text.IndexOf(")");
                    textBox1.Text = textBox1.Text.Remove(index,1);
                }
            }
        }
        private void lbAC_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length <= 11)
                textBox1.Text = "";
            else lbequal_Click(sender, e);
        }

        private void lbDelete_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text.Remove(textBox1.Text.Length - 1);
        }
        private double Calculating(double value1, double value2, char sympol)
        {
            double result = 0;
            switch (sympol)
            {
                case '+':
                    result = value1 + value2;
                    break;
                case '-':
                    result = value1 - value2;
                    break;
                case '/':
                    result = value1 / value2;
                    break;
                case '*':
                    result = value1 * value2;
                    break;
                case '%':
                    result = value1 % value2;
                    break;
            }
            return result;
        }
        private double GetSupString(int index_sympol, string original_text, bool end_operation)
        {
            double sub_digits;

             if (Text[0] == '-')
            {
                sign = -1;
                textBox1.Text = textBox1.Text.Remove(0, 1);
            }

            if (index_sympol == original_text.Length - 1)
            {
                end_operation = true;
                sub_digits = sign * Convert.ToDouble(original_text.Substring(0, index_sympol+1));
                sign = 1;
                return sub_digits;
            }

            sub_digits = sign*Convert.ToDouble(original_text.Substring(0, index_sympol));
            sign = 1;

            return sub_digits;
        }
        private bool IsSympolMultiOrDivOrMod(char sympol)
        {
            return sympol == '*' || sympol == '/' || sympol == '%';
        }
        private bool IsSympol(char sympol)
        {
            return sympol == '+' || sympol == '-' || sympol == '/' || sympol == '*' || sympol == '%';
        }
        private void Calculator(string expreesion,bool CalcInBracket=false)
        {
            
            bool end_operation = false;
            string Text = expreesion;
            double sub_digits;
            char sympol = ' ', sympol2 = ' ', sympol3 = ' ';

            if (Text[0] == '-')
            {
                sign = -1;
                Text = Text.Remove(0, 1);
            }

            for (short i = 0; i < Text.Length; i++)
            {
                if (IsSympol(Text[i]) || i == Text.Length - 1)
                {
                    if (sympol != ' ')
                    {
                        sub_digits = GetSupString(i, Text, end_operation);

                        bool done = false;

                        if (IsSympolMultiOrDivOrMod(Text[i]))
                        {
                            sympol2 = Text[i];

                            Text = Text.Remove(0, i + 1);
                            done = true;

                            for (int j = 0; j < Text.Length; j++)
                            {
                                if (IsSympol(Text[j]) || j == Text.Length - 1)
                                {
                                    double sup_digits2;
                                    sup_digits2 = GetSupString(j, Text, end_operation);
                                    sub_digits = Calculating(sub_digits, sup_digits2, sympol2);

                                    sympol3 = Text[j];

                                    Text = Text.Remove(0, j + 1);

                                    if (!IsSympolMultiOrDivOrMod(sympol3))
                                        break;

                                    else
                                    {
                                        sympol2 = sympol3;
                                        j = -1;
                                    }
                                }
                            }
                        }
                        result = Calculating(result, sub_digits, sympol);

                        if (end_operation)
                            break;

                        // if next sympol not equal * or / or %
                        if (!done)
                        {
                            sympol = Text[i];
                            Text = Text.Remove(0, i + 1);

                        }

                        else
                        {
                            sympol = sympol3;

                        }


                        i = -1;
                        continue;
                    }
                    sympol = Text[i];
    
                    
                    result = sign*Convert.ToDouble(Text.Substring(0, i));
                    sign = 1;

                    Text = Text.Remove(0, i + 1);
                    i = -1;
                }
            }
            if(!CalcInBracket)
            textBox1.Text = result.ToString();
        }
        private void lbequal_Click(object sender, EventArgs e)
        {

            Calc_InBracket();
            Calculator(textBox1.Text);
        }
    }
}
