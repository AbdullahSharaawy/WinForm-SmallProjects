﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbAC = new System.Windows.Forms.Label();
            this.lbbracet = new System.Windows.Forms.Label();
            this.lbmod = new System.Windows.Forms.Label();
            this.lbdivision = new System.Windows.Forms.Label();
            this.lb7 = new System.Windows.Forms.Label();
            this.lb8 = new System.Windows.Forms.Label();
            this.lb9 = new System.Windows.Forms.Label();
            this.lbmulti = new System.Windows.Forms.Label();
            this.lb6 = new System.Windows.Forms.Label();
            this.lb5 = new System.Windows.Forms.Label();
            this.lb4 = new System.Windows.Forms.Label();
            this.lb3 = new System.Windows.Forms.Label();
            this.lb2 = new System.Windows.Forms.Label();
            this.lb1 = new System.Windows.Forms.Label();
            this.lbDelete = new System.Windows.Forms.Label();
            this.lbdot = new System.Windows.Forms.Label();
            this.lb0 = new System.Windows.Forms.Label();
            this.lbminus = new System.Windows.Forms.Label();
            this.lbplus = new System.Windows.Forms.Label();
            this.lbequal = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbAC
            // 
            this.lbAC.AutoSize = true;
            this.lbAC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(0)))));
            this.lbAC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbAC.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAC.ForeColor = System.Drawing.Color.White;
            this.lbAC.Location = new System.Drawing.Point(20, 100);
            this.lbAC.Name = "lbAC";
            this.lbAC.Size = new System.Drawing.Size(52, 31);
            this.lbAC.TabIndex = 1;
            this.lbAC.Text = "AC";
            this.lbAC.Click += new System.EventHandler(this.lbAC_Click);
            // 
            // lbbracet
            // 
            this.lbbracet.AutoSize = true;
            this.lbbracet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(150)))));
            this.lbbracet.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbbracet.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbbracet.ForeColor = System.Drawing.Color.White;
            this.lbbracet.Location = new System.Drawing.Point(108, 98);
            this.lbbracet.Name = "lbbracet";
            this.lbbracet.Size = new System.Drawing.Size(39, 31);
            this.lbbracet.TabIndex = 2;
            this.lbbracet.Text = "( )";
            this.lbbracet.Click += new System.EventHandler(this.lbbracet_Click);
            // 
            // lbmod
            // 
            this.lbmod.AutoSize = true;
            this.lbmod.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(150)))));
            this.lbmod.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbmod.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbmod.ForeColor = System.Drawing.Color.White;
            this.lbmod.Location = new System.Drawing.Point(190, 100);
            this.lbmod.Name = "lbmod";
            this.lbmod.Size = new System.Drawing.Size(38, 31);
            this.lbmod.TabIndex = 3;
            this.lbmod.Text = "%";
            this.lbmod.Click += new System.EventHandler(this.lbmod_Click);
            // 
            // lbdivision
            // 
            this.lbdivision.AutoSize = true;
            this.lbdivision.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(150)))));
            this.lbdivision.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbdivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbdivision.ForeColor = System.Drawing.Color.White;
            this.lbdivision.Location = new System.Drawing.Point(275, 100);
            this.lbdivision.Name = "lbdivision";
            this.lbdivision.Size = new System.Drawing.Size(22, 31);
            this.lbdivision.TabIndex = 4;
            this.lbdivision.Text = "/";
            this.lbdivision.Click += new System.EventHandler(this.lbdivision_Click);
            // 
            // lb7
            // 
            this.lb7.AutoSize = true;
            this.lb7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.lb7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lb7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb7.ForeColor = System.Drawing.Color.White;
            this.lb7.Location = new System.Drawing.Point(30, 180);
            this.lb7.Name = "lb7";
            this.lb7.Size = new System.Drawing.Size(29, 31);
            this.lb7.TabIndex = 5;
            this.lb7.Text = "7";
            this.lb7.Click += new System.EventHandler(this.lb7_Click_1);
            // 
            // lb8
            // 
            this.lb8.AutoSize = true;
            this.lb8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.lb8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lb8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb8.ForeColor = System.Drawing.Color.White;
            this.lb8.Location = new System.Drawing.Point(115, 180);
            this.lb8.Name = "lb8";
            this.lb8.Size = new System.Drawing.Size(29, 31);
            this.lb8.TabIndex = 6;
            this.lb8.Text = "8";
            this.lb8.Click += new System.EventHandler(this.lb8_Click);
            // 
            // lb9
            // 
            this.lb9.AutoSize = true;
            this.lb9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.lb9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lb9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb9.ForeColor = System.Drawing.Color.White;
            this.lb9.Location = new System.Drawing.Point(195, 180);
            this.lb9.Name = "lb9";
            this.lb9.Size = new System.Drawing.Size(29, 31);
            this.lb9.TabIndex = 7;
            this.lb9.Text = "9";
            this.lb9.Click += new System.EventHandler(this.lb9_Click);
            // 
            // lbmulti
            // 
            this.lbmulti.AutoSize = true;
            this.lbmulti.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(150)))));
            this.lbmulti.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbmulti.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbmulti.ForeColor = System.Drawing.Color.White;
            this.lbmulti.Location = new System.Drawing.Point(275, 185);
            this.lbmulti.Name = "lbmulti";
            this.lbmulti.Size = new System.Drawing.Size(25, 31);
            this.lbmulti.TabIndex = 8;
            this.lbmulti.Text = "*";
            this.lbmulti.Click += new System.EventHandler(this.lbmulti_Click);
            // 
            // lb6
            // 
            this.lb6.AutoSize = true;
            this.lb6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.lb6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lb6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb6.ForeColor = System.Drawing.Color.White;
            this.lb6.Location = new System.Drawing.Point(190, 257);
            this.lb6.Name = "lb6";
            this.lb6.Size = new System.Drawing.Size(29, 31);
            this.lb6.TabIndex = 11;
            this.lb6.Text = "6";
            this.lb6.Click += new System.EventHandler(this.lb6_Click);
            // 
            // lb5
            // 
            this.lb5.AutoSize = true;
            this.lb5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.lb5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lb5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb5.ForeColor = System.Drawing.Color.White;
            this.lb5.Location = new System.Drawing.Point(110, 257);
            this.lb5.Name = "lb5";
            this.lb5.Size = new System.Drawing.Size(29, 31);
            this.lb5.TabIndex = 10;
            this.lb5.Text = "5";
            this.lb5.Click += new System.EventHandler(this.lb5_Click);
            // 
            // lb4
            // 
            this.lb4.AutoSize = true;
            this.lb4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.lb4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lb4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb4.ForeColor = System.Drawing.Color.White;
            this.lb4.Location = new System.Drawing.Point(30, 257);
            this.lb4.Name = "lb4";
            this.lb4.Size = new System.Drawing.Size(29, 31);
            this.lb4.TabIndex = 9;
            this.lb4.Text = "4";
            this.lb4.Click += new System.EventHandler(this.lb4_Click);
            // 
            // lb3
            // 
            this.lb3.AutoSize = true;
            this.lb3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.lb3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lb3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb3.ForeColor = System.Drawing.Color.White;
            this.lb3.Location = new System.Drawing.Point(193, 340);
            this.lb3.Name = "lb3";
            this.lb3.Size = new System.Drawing.Size(29, 31);
            this.lb3.TabIndex = 14;
            this.lb3.Text = "3";
            this.lb3.Click += new System.EventHandler(this.lb3_Click);
            // 
            // lb2
            // 
            this.lb2.AutoSize = true;
            this.lb2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.lb2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lb2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb2.ForeColor = System.Drawing.Color.White;
            this.lb2.Location = new System.Drawing.Point(115, 340);
            this.lb2.Name = "lb2";
            this.lb2.Size = new System.Drawing.Size(29, 31);
            this.lb2.TabIndex = 13;
            this.lb2.Text = "2";
            this.lb2.Click += new System.EventHandler(this.lb2_Click);
            // 
            // lb1
            // 
            this.lb1.AutoSize = true;
            this.lb1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.lb1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lb1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb1.ForeColor = System.Drawing.Color.White;
            this.lb1.Location = new System.Drawing.Point(30, 340);
            this.lb1.Name = "lb1";
            this.lb1.Size = new System.Drawing.Size(29, 31);
            this.lb1.TabIndex = 12;
            this.lb1.Text = "1";
            this.lb1.Click += new System.EventHandler(this.lb1_Click);
            // 
            // lbDelete
            // 
            this.lbDelete.AutoSize = true;
            this.lbDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.lbDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDelete.ForeColor = System.Drawing.Color.White;
            this.lbDelete.Location = new System.Drawing.Point(185, 420);
            this.lbDelete.Name = "lbDelete";
            this.lbDelete.Size = new System.Drawing.Size(46, 31);
            this.lbDelete.TabIndex = 17;
            this.lbDelete.Text = "<+";
            this.lbDelete.Click += new System.EventHandler(this.lbDelete_Click);
            // 
            // lbdot
            // 
            this.lbdot.AutoSize = true;
            this.lbdot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.lbdot.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbdot.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbdot.ForeColor = System.Drawing.Color.White;
            this.lbdot.Location = new System.Drawing.Point(115, 410);
            this.lbdot.Name = "lbdot";
            this.lbdot.Size = new System.Drawing.Size(22, 31);
            this.lbdot.TabIndex = 16;
            this.lbdot.Text = ".";
            this.lbdot.Click += new System.EventHandler(this.lbdot_Click);
            // 
            // lb0
            // 
            this.lb0.AutoSize = true;
            this.lb0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.lb0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lb0.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb0.ForeColor = System.Drawing.Color.White;
            this.lb0.Location = new System.Drawing.Point(30, 418);
            this.lb0.Name = "lb0";
            this.lb0.Size = new System.Drawing.Size(29, 31);
            this.lb0.TabIndex = 15;
            this.lb0.Text = "0";
            this.lb0.Click += new System.EventHandler(this.lb0_Click);
            // 
            // lbminus
            // 
            this.lbminus.AutoSize = true;
            this.lbminus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(150)))));
            this.lbminus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbminus.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbminus.ForeColor = System.Drawing.Color.White;
            this.lbminus.Location = new System.Drawing.Point(275, 250);
            this.lbminus.Name = "lbminus";
            this.lbminus.Size = new System.Drawing.Size(29, 31);
            this.lbminus.TabIndex = 18;
            this.lbminus.Text = "_";
            this.lbminus.Click += new System.EventHandler(this.lbminus_Click);
            // 
            // lbplus
            // 
            this.lbplus.AutoSize = true;
            this.lbplus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(150)))));
            this.lbplus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbplus.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbplus.ForeColor = System.Drawing.Color.White;
            this.lbplus.Location = new System.Drawing.Point(275, 340);
            this.lbplus.Name = "lbplus";
            this.lbplus.Size = new System.Drawing.Size(30, 31);
            this.lbplus.TabIndex = 19;
            this.lbplus.Text = "+";
            this.lbplus.Click += new System.EventHandler(this.lbplus_Click);
            // 
            // lbequal
            // 
            this.lbequal.AutoSize = true;
            this.lbequal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(150)))));
            this.lbequal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbequal.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbequal.ForeColor = System.Drawing.Color.White;
            this.lbequal.Location = new System.Drawing.Point(275, 420);
            this.lbequal.Name = "lbequal";
            this.lbequal.Size = new System.Drawing.Size(30, 31);
            this.lbequal.TabIndex = 20;
            this.lbequal.Text = "=";
            this.lbequal.Click += new System.EventHandler(this.lbequal_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(2, 3);
            this.textBox1.MaxLength = 9;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(337, 55);
            this.textBox1.TabIndex = 21;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(341, 493);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lbequal);
            this.Controls.Add(this.lbplus);
            this.Controls.Add(this.lbminus);
            this.Controls.Add(this.lbDelete);
            this.Controls.Add(this.lbdot);
            this.Controls.Add(this.lb0);
            this.Controls.Add(this.lb3);
            this.Controls.Add(this.lb2);
            this.Controls.Add(this.lb1);
            this.Controls.Add(this.lb6);
            this.Controls.Add(this.lb5);
            this.Controls.Add(this.lb4);
            this.Controls.Add(this.lbmulti);
            this.Controls.Add(this.lb9);
            this.Controls.Add(this.lb8);
            this.Controls.Add(this.lb7);
            this.Controls.Add(this.lbdivision);
            this.Controls.Add(this.lbmod);
            this.Controls.Add(this.lbbracet);
            this.Controls.Add(this.lbAC);
            this.Name = "Form1";
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lbAC;
        private System.Windows.Forms.Label lbbracet;
        private System.Windows.Forms.Label lbmod;
        private System.Windows.Forms.Label lbdivision;
        private System.Windows.Forms.Label lb7;
        private System.Windows.Forms.Label lb8;
        private System.Windows.Forms.Label lb9;
        private System.Windows.Forms.Label lbmulti;
        private System.Windows.Forms.Label lb6;
        private System.Windows.Forms.Label lb5;
        private System.Windows.Forms.Label lb4;
        private System.Windows.Forms.Label lb3;
        private System.Windows.Forms.Label lb2;
        private System.Windows.Forms.Label lb1;
        private System.Windows.Forms.Label lbDelete;
        private System.Windows.Forms.Label lbdot;
        private System.Windows.Forms.Label lb0;
        private System.Windows.Forms.Label lbminus;
        private System.Windows.Forms.Label lbplus;
        private System.Windows.Forms.Label lbequal;
        private System.Windows.Forms.TextBox textBox1;
    }
}

