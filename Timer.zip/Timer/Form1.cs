﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private long  Seconds = 55, Minuets =0 ,Hourses=0;
        
        private void PrintTimer()
        {
            if (Hourses != 0)
            {
                lbSecond.Font = new Font(lbSecond.Font.FontFamily, 30);
                lbSecond.Font = new Font(lbSecond.Font, FontStyle.Bold);
                lbSecond.Location = new Point(80, 155);
             
                lbSecond.Text = Hourses.ToString() + " : " + Minuets.ToString() + " : " + Seconds.ToString();
            }
            else if (Minuets != 0)
            {
                lbSecond.Text = Minuets.ToString() + " : " + Seconds.ToString();
                lbSecond.Location = new Point(90, 160);
                lbSecond.Font = new Font(lbSecond.Font, FontStyle.Bold);
            }
            else
                lbSecond.Text = Seconds.ToString();

        }
        private void timer1_Tick(object sender, EventArgs e)
        {
           

            if (Seconds==60)
            {
                Minuets++;
                Seconds = 0;
            }
            else
            {
                Seconds++;

            }
            if (Minuets==60)
            {
                Hourses++;
                Minuets = 0;
            }
            PrintTimer();
           
        }

        private void btStart2_Click(object sender, EventArgs e)
        {
            Image image = Properties.Resources.R__5_;
            btStart.Image = image;
            timer1.Enabled = false;
            btStart2.Visible = false;
            btStart.Visible = true;
          
        }

       
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Color Black = Color.FromArgb(255, 0, 0, 0);
            Color White = Color.FromArgb(255, 50, 50, 50);

            Pen Pen = new Pen(Black);
            Pen.Width = 130;
            Pen WPen = new Pen(White);
            WPen.Width = 5;

            // Pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            Pen.StartCap = System.Drawing.Drawing2D.LineCap.Round;
            Pen.EndCap = System.Drawing.Drawing2D.LineCap.Round;

            WPen.StartCap = System.Drawing.Drawing2D.LineCap.Round;
            WPen.EndCap = System.Drawing.Drawing2D.LineCap.Round;


            e.Graphics.DrawEllipse(Pen, 90, 90, 130, 200);
            e.Graphics.DrawEllipse(WPen, 20, 30, 270, 320);

        }

        private void guna2CirclePictureBox2_Click(object sender, EventArgs e)
        {
            Form form = new Form2();
            form.Show();
        }

        private void btStart_Click(object sender, EventArgs e)
        {
                timer1.Enabled = true;
                btStart.Visible = false;
                btStart2.Visible = true;
                Image image = Properties.Resources.R__6_;
                btStart2.Image = image;
           
        }

        private void btReset_Click(object sender, EventArgs e)
        {
            Seconds = 0; 
            Minuets = 0;
            Hourses = 0;
            lbSecond.Location = new Point(126, 155);
            lbSecond.Text = "00";
            timer1.Enabled = false;
            btStart2.Visible = false;
            btStart.Visible = true;
        }

      

       
    }
}
