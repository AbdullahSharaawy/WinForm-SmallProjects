﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using Guna.UI2.WinForms;
namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();

        }


        private SoundPlayer _Sound=new SoundPlayer("mixkit-classic-alarm-995.WAV");
      
        private void btStart_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            lbRun.Text = "Runing......";
        }

        private void btStop_Click(object sender, EventArgs e)
        {
            timer1.Enabled=false;
            lbRun.Text = "";
            _Sound.Stop();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
           DateTime AlarmTime = dateTimePicker1.Value;
            DateTime TimeNow=DateTime.Now;

            if (AlarmTime.Hour == TimeNow.Hour && AlarmTime.Minute == TimeNow.Minute && AlarmTime.Second == TimeNow.Second )
            {
                lbRun.Text = "Ring Ring Ring ...";

                notifyIcon1.Icon = SystemIcons.Application;
                notifyIcon1.BalloonTipIcon = ToolTipIcon.Warning;
                notifyIcon1.BalloonTipTitle = "Your Alarm is Runing";
                notifyIcon1.BalloonTipText = "Wake up man ";
                notifyIcon1.ShowBalloonTip(1000);

                _Sound.Play();


            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void btStart_MouseHover(object sender, EventArgs e)
        {
            btStart.BackColor = Color.Blue;
        }

        private void btStart_MouseLeave(object sender, EventArgs e)
        {
            btStart.BackColor = Color.Black;
        }

        private void btStart_MouseDown(object sender, MouseEventArgs e)
        {
            btStart.BackColor = Color.Green;
        }
      
      

        private void btStop_MouseDown_1(object sender, MouseEventArgs e)
        {
            btStop.BackColor = Color.Green;
        }

        private void btStop_MouseEnter(object sender, EventArgs e)
        {
            btStop.BackColor = Color.Blue;
        }

        private void btStop_MouseLeave(object sender, EventArgs e)
        {
            btStop.BackColor = Color.Black;
        }

        private void notifyIcon1_BalloonTipClicked(object sender, EventArgs e)
        {
           
              
            
        }
    }
}
