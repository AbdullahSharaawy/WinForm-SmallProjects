﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lbSecond = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.btStart2 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2CirclePictureBox2 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.btReset = new Guna.UI2.WinForms.Guna2GradientCircleButton();
            this.btStart = new Guna.UI2.WinForms.Guna2GradientCircleButton();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lbSecond
            // 
            this.lbSecond.AutoSize = true;
            this.lbSecond.BackColor = System.Drawing.Color.Black;
            this.lbSecond.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSecond.ForeColor = System.Drawing.Color.White;
            this.lbSecond.Location = new System.Drawing.Point(126, 155);
            this.lbSecond.Name = "lbSecond";
            this.lbSecond.Size = new System.Drawing.Size(80, 55);
            this.lbSecond.TabIndex = 0;
            this.lbSecond.Text = "00";
            // 
            // timer2
            // 
            this.timer2.Interval = 1;
            // 
            // btStart2
            // 
            this.btStart2.Animated = true;
            this.btStart2.BorderRadius = 10;
            this.btStart2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btStart2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btStart2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btStart2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btStart2.FillColor = System.Drawing.Color.LightSkyBlue;
            this.btStart2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btStart2.ForeColor = System.Drawing.Color.White;
            this.btStart2.Location = new System.Drawing.Point(97, 380);
            this.btStart2.Name = "btStart2";
            this.btStart2.Size = new System.Drawing.Size(119, 43);
            this.btStart2.TabIndex = 5;
            this.btStart2.Visible = false;
            this.btStart2.Click += new System.EventHandler(this.btStart2_Click);
            // 
            // guna2CirclePictureBox2
            // 
            this.guna2CirclePictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CirclePictureBox2.Image = global::WindowsFormsApp1.Properties.Resources.OIP__6_;
            this.guna2CirclePictureBox2.ImageRotate = 0F;
            this.guna2CirclePictureBox2.Location = new System.Drawing.Point(23, 432);
            this.guna2CirclePictureBox2.Name = "guna2CirclePictureBox2";
            this.guna2CirclePictureBox2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox2.Size = new System.Drawing.Size(47, 45);
            this.guna2CirclePictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2CirclePictureBox2.TabIndex = 7;
            this.guna2CirclePictureBox2.TabStop = false;
            this.guna2CirclePictureBox2.Click += new System.EventHandler(this.guna2CirclePictureBox2_Click);
            // 
            // btReset
            // 
            this.btReset.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btReset.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btReset.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btReset.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btReset.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btReset.FillColor = System.Drawing.Color.DarkTurquoise;
            this.btReset.FillColor2 = System.Drawing.Color.DarkTurquoise;
            this.btReset.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.btReset.ForeColor = System.Drawing.Color.Black;
            this.btReset.Image = global::WindowsFormsApp1.Properties.Resources.R__4_;
            this.btReset.Location = new System.Drawing.Point(237, 384);
            this.btReset.Name = "btReset";
            this.btReset.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.btReset.Size = new System.Drawing.Size(39, 39);
            this.btReset.TabIndex = 4;
            this.btReset.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SingleBitPerPixelGridFit;
            this.btReset.Click += new System.EventHandler(this.btReset_Click);
            // 
            // btStart
            // 
            this.btStart.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btStart.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btStart.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btStart.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btStart.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btStart.FillColor = System.Drawing.Color.LightSkyBlue;
            this.btStart.FillColor2 = System.Drawing.Color.LightSkyBlue;
            this.btStart.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btStart.ForeColor = System.Drawing.Color.Black;
            this.btStart.Image = global::WindowsFormsApp1.Properties.Resources.R__5_;
            this.btStart.Location = new System.Drawing.Point(118, 362);
            this.btStart.Name = "btStart";
            this.btStart.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.btStart.Size = new System.Drawing.Size(88, 75);
            this.btStart.TabIndex = 3;
            this.btStart.Click += new System.EventHandler(this.btStart_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.ClientSize = new System.Drawing.Size(317, 489);
            this.Controls.Add(this.guna2CirclePictureBox2);
            this.Controls.Add(this.btStart2);
            this.Controls.Add(this.btReset);
            this.Controls.Add(this.btStart);
            this.Controls.Add(this.lbSecond);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lbSecond;
        private Guna.UI2.WinForms.Guna2GradientCircleButton btStart;
        private Guna.UI2.WinForms.Guna2GradientCircleButton btReset;
        private System.Windows.Forms.Timer timer2;
        private Guna.UI2.WinForms.Guna2Button btStart2;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox2;
    }
}

