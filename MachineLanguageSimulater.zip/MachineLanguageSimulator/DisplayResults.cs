﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task4_GUI
{
    public partial class DisplayResults : Form
    {
        private int counter = 1,counter_ZeroCellTable=0;
        private List<DataTable> _MemoryTable;
        private List<DataTable> _RegisterTable;
        private List<string> _InstructionTable;
        private List<int> _PCTable;
        private int TableSize;
        private List<DataTable> _ZeroCellTable;
        private bool _PrintEachStep = false;
        public DisplayResults(List<DataTable> ZeroCellTable, bool PrintEachStep,List<DataTable> MemoryTable,List<DataTable> RegisterTable,List<int> pc ,List< string> ir)
        {
            InitializeComponent();
           
            // get all machine data
            _MemoryTable = MemoryTable.ToList();
            _RegisterTable = RegisterTable.ToList();
            _InstructionTable = ir.ToList();
            _PCTable = pc.ToList();
            _ZeroCellTable = ZeroCellTable;
            _PrintEachStep = PrintEachStep;
            // display first excute

            if (PrintEachStep)
                Display(0);
            else
            {
                btNext.Enabled = false;
                Display(SelectIndexLastElement(_MemoryTable));      
            }
                
            // change properties of controls 
            ChangeProperties();

           

        }
        private int SelectIndexLastElement(List<DataTable> list) // select last index of last element where does`nt equal null
        {
            for (int i = 0; i < list.Count; i++) 
                {
                       if (list[i] == null)
                              return i-1;
                }
            return list.Count-1;
        }
       
        private void ChangeProperties()
        {
            dgMemory.EnableHeadersVisualStyles = false;
            dgRegisters.EnableHeadersVisualStyles = false;
            dgScreen.EnableHeadersVisualStyles = false;
            
            dgMemory.DefaultCellStyle.BackColor = Color.Black;
            dgRegisters.DefaultCellStyle.BackColor = Color.Black;
            dgScreen.DefaultCellStyle.BackColor = Color.Black;

            dgMemory.DefaultCellStyle.ForeColor = Color.White;
            dgRegisters.DefaultCellStyle.ForeColor = Color.White;
            dgScreen.DefaultCellStyle.ForeColor = Color.White;

            dgMemory.RowHeadersDefaultCellStyle.BackColor = Color.Black;
            dgScreen.RowHeadersDefaultCellStyle.BackColor = Color.Black;
            dgMemory.ColumnHeadersDefaultCellStyle.BackColor = Color.Black;
            dgScreen.ColumnHeadersDefaultCellStyle.BackColor = Color.Black;

            dgMemory.RowHeadersDefaultCellStyle.ForeColor = Color.White;
            dgMemory.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgScreen.RowHeadersDefaultCellStyle.ForeColor = Color.White;
            dgScreen.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            dgRegisters.RowHeadersDefaultCellStyle.BackColor = Color.Black;
            dgRegisters.ColumnHeadersDefaultCellStyle.BackColor = Color.Black;

            dgRegisters.RowHeadersDefaultCellStyle.ForeColor = Color.White;
            dgRegisters.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;


            lbResults.BackColor = Color.FromArgb(128, Color.Black);

            btNext.FlatAppearance.BorderColor = Color.Green;
        }
        private void Display(int index)
        {

            if (_MemoryTable[index] != null)
                dgMemory.DataSource = _MemoryTable[index];
            
            
            if (_RegisterTable[index] !=null)
                dgRegisters.DataSource = _RegisterTable[index];
            if (counter_ZeroCellTable < _ZeroCellTable.Count && _ZeroCellTable[counter_ZeroCellTable] != null && _ZeroCellTable[counter_ZeroCellTable].Rows[counter_ZeroCellTable]["Hexa"].ToString() == dgMemory.Rows[0].Cells[1].Value.ToString())
            {
                
                    dgScreen.DataSource = _ZeroCellTable[counter_ZeroCellTable];
                counter_ZeroCellTable++;
            }
            else if(_ZeroCellTable.Count - 1 > 0 && !_PrintEachStep)
            {
                dgScreen.DataSource = _ZeroCellTable[_ZeroCellTable.Count - 1];
            }
            if (index<_InstructionTable.Count)
            {
                if (_InstructionTable[index] != null)
                    lbIR.Text = "IR: " + _InstructionTable[index];

                if (_PCTable[index] != 0)
                    lbPC.Text = "PC: " + _PCTable[index].ToString();

            }


        }
        private void dgRegisters_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void dgRegisters_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
           

        }

        private void DisplayResults_Load(object sender, EventArgs e)
        {
            foreach (DataGridViewColumn column in dgRegisters.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            foreach (DataGridViewColumn column in dgMemory.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            foreach (DataGridViewColumn column in dgScreen.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
        }

        private void btNext_Click(object sender, EventArgs e)
        {
            if (counter<=SelectIndexLastElement( _MemoryTable))
            {
                Display(counter);
                
                counter++;
            }else
                btNext.Enabled = false;

        }

        private void btNext_MouseHover(object sender, EventArgs e)
        {
            ToolTip toolTip = new ToolTip();
            toolTip.Show("excute next instruction", btNext, 10);
        }
    }
}
