﻿namespace Task4_GUI
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenu));
            this.btEnter = new System.Windows.Forms.Button();
            this.btExcute = new System.Windows.Forms.Button();
            this.btExist = new System.Windows.Forms.Button();
            this.tbIstructions = new System.Windows.Forms.TextBox();
            this.lbWelcome = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btClear = new System.Windows.Forms.Button();
            this.lbStartPoint = new System.Windows.Forms.Label();
            this.mtbStartPoint = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // btEnter
            // 
            this.btEnter.BackColor = System.Drawing.Color.Black;
            this.btEnter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btEnter.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btEnter.ForeColor = System.Drawing.Color.Lime;
            this.btEnter.Location = new System.Drawing.Point(68, 166);
            this.btEnter.Name = "btEnter";
            this.btEnter.Size = new System.Drawing.Size(176, 51);
            this.btEnter.TabIndex = 0;
            this.btEnter.Text = "Enter Instructions";
            this.btEnter.UseMnemonic = false;
            this.btEnter.UseVisualStyleBackColor = false;
            this.btEnter.Click += new System.EventHandler(this.btEnter_Click);
            // 
            // btExcute
            // 
            this.btExcute.BackColor = System.Drawing.Color.Black;
            this.btExcute.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btExcute.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btExcute.ForeColor = System.Drawing.Color.Lime;
            this.btExcute.Location = new System.Drawing.Point(68, 256);
            this.btExcute.Name = "btExcute";
            this.btExcute.Size = new System.Drawing.Size(176, 51);
            this.btExcute.TabIndex = 1;
            this.btExcute.Text = "Execute ";
            this.btExcute.UseMnemonic = false;
            this.btExcute.UseVisualStyleBackColor = false;
            this.btExcute.Click += new System.EventHandler(this.btExcute_Click);
            // 
            // btExist
            // 
            this.btExist.BackColor = System.Drawing.Color.Black;
            this.btExist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btExist.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btExist.ForeColor = System.Drawing.Color.Lime;
            this.btExist.Location = new System.Drawing.Point(68, 346);
            this.btExist.Name = "btExist";
            this.btExist.Size = new System.Drawing.Size(176, 51);
            this.btExist.TabIndex = 2;
            this.btExist.Text = "Exist";
            this.btExist.UseMnemonic = false;
            this.btExist.UseVisualStyleBackColor = false;
            this.btExist.Click += new System.EventHandler(this.btExist_Click);
            // 
            // tbIstructions
            // 
            this.tbIstructions.BackColor = System.Drawing.Color.Black;
            this.tbIstructions.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbIstructions.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIstructions.ForeColor = System.Drawing.Color.Lime;
            this.tbIstructions.Location = new System.Drawing.Point(359, 166);
            this.tbIstructions.Multiline = true;
            this.tbIstructions.Name = "tbIstructions";
            this.tbIstructions.Size = new System.Drawing.Size(307, 231);
            this.tbIstructions.TabIndex = 3;
            this.tbIstructions.Visible = false;
            // 
            // lbWelcome
            // 
            this.lbWelcome.AutoSize = true;
            this.lbWelcome.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbWelcome.ForeColor = System.Drawing.Color.Lime;
            this.lbWelcome.Location = new System.Drawing.Point(270, 23);
            this.lbWelcome.Name = "lbWelcome";
            this.lbWelcome.Size = new System.Drawing.Size(266, 33);
            this.lbWelcome.TabIndex = 4;
            this.lbWelcome.Text = "Machine Language";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Lime;
            this.label1.Location = new System.Drawing.Point(432, 135);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 19);
            this.label1.TabIndex = 5;
            this.label1.Text = "Your Instructions";
            this.label1.Visible = false;
            // 
            // btClear
            // 
            this.btClear.BackColor = System.Drawing.Color.Lime;
            this.btClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btClear.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btClear.ForeColor = System.Drawing.Color.Black;
            this.btClear.Location = new System.Drawing.Point(359, 403);
            this.btClear.Name = "btClear";
            this.btClear.Size = new System.Drawing.Size(75, 23);
            this.btClear.TabIndex = 6;
            this.btClear.Text = "Clear";
            this.btClear.UseVisualStyleBackColor = false;
            this.btClear.Visible = false;
            this.btClear.Click += new System.EventHandler(this.btClear_Click);
            // 
            // lbStartPoint
            // 
            this.lbStartPoint.AutoSize = true;
            this.lbStartPoint.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbStartPoint.ForeColor = System.Drawing.Color.Lime;
            this.lbStartPoint.Location = new System.Drawing.Point(483, 407);
            this.lbStartPoint.Name = "lbStartPoint";
            this.lbStartPoint.Size = new System.Drawing.Size(89, 18);
            this.lbStartPoint.TabIndex = 7;
            this.lbStartPoint.Text = "Start Point";
            this.lbStartPoint.Visible = false;
            // 
            // mtbStartPoint
            // 
            this.mtbStartPoint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.mtbStartPoint.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.mtbStartPoint.ForeColor = System.Drawing.Color.White;
            this.mtbStartPoint.Location = new System.Drawing.Point(594, 407);
            this.mtbStartPoint.Mask = "000";
            this.mtbStartPoint.Name = "mtbStartPoint";
            this.mtbStartPoint.Size = new System.Drawing.Size(67, 13);
            this.mtbStartPoint.TabIndex = 8;
            this.mtbStartPoint.Text = "10";
            this.mtbStartPoint.ValidatingType = typeof(int);
            this.mtbStartPoint.Visible = false;
            this.mtbStartPoint.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.mtbStartPoint_MaskInputRejected);
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(726, 548);
            this.Controls.Add(this.mtbStartPoint);
            this.Controls.Add(this.lbStartPoint);
            this.Controls.Add(this.btClear);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbWelcome);
            this.Controls.Add(this.tbIstructions);
            this.Controls.Add(this.btExist);
            this.Controls.Add(this.btExcute);
            this.Controls.Add(this.btEnter);
            this.Name = "MainMenu";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btEnter;
        private System.Windows.Forms.Button btExcute;
        private System.Windows.Forms.Button btExist;
        private System.Windows.Forms.TextBox tbIstructions;
        private System.Windows.Forms.Label lbWelcome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btClear;
        private System.Windows.Forms.Label lbStartPoint;
        private System.Windows.Forms.MaskedTextBox mtbStartPoint;
    }
}

