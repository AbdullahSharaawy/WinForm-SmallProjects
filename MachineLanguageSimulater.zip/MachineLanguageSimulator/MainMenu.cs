﻿using BusinessLayer;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Task4_GUI
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lbWelcome.BackColor = Color.FromArgb(128, Color.Black);
            label1.BackColor = Color.FromArgb(128, Color.Black);
            lbStartPoint.BackColor = Color.FromArgb(128, Color.Black);
        }

        private void btEnter_Click(object sender, EventArgs e)
        {
            tbIstructions.Visible = true;
            label1.Visible = true;
            btClear.Visible = true;
            mtbStartPoint.Visible = true;
            lbStartPoint.Visible = true;
        }
       private string Trim(string text)
        {
            // Remove spaces at the beginning
            if (text.Length == 0)
                return "";

            int start = 0;
            while (start < text.Length && text[start] == ' ')
            {
                start++;
            }

            // Remove spaces at the end
            int end = text.Length - 1;
            while (end > start && text[end] == ' ')
            {
                end--;
            }

            return text.Substring(start, end - start + 1);
        }
        private string ConvertToHexa(string line)
        {
            StringBuilder modifiedLine = new StringBuilder();

            foreach (char c in line)
            {
                int n = -1;

                if (char.IsDigit(c))
                    n = c - '0';
                else if (char.IsLetter(c))
                    n = c - 'A';

                if (n > 15 || n < 0)
                {
                    modifiedLine.Append(' '); // Append a space if condition is met
                }
                else
                {
                    modifiedLine.Append(c); // Append the original character if condition is not met
                }
            }

             line = modifiedLine.ToString(); // Get the modified string

            return line;
    }
    private List<string> ProccessingListOfInstructions( List<string> instructions)
        {
            List<string> list = new List<string>();//new instructions

            foreach ( string  instruction in instructions)
            {
                string line = instruction;
                line=line.ToUpper();
                line=ConvertToHexa(line);
                if (!string.IsNullOrEmpty(line))
                {
                    line = Trim(line);
                    line += ' ';
                    while (line.Length >= 4)
                    {

                        line = line.Replace("\r", "");
        
                        list.Add(line.Substring(0, line.IndexOf(' ')));
                        line = line.Remove(0, line.IndexOf(' ') + 1);
                        line = Trim(line);
                        line += ' ';
                    }
                }

            }

            if (!list.Contains("C000"))
                list.Add("C000");
            return list;
        }
        private void btExcute_Click(object sender, EventArgs e)
        {
             List<string> Instructions = new List<string>(tbIstructions.Text.Split(new[] { '\n' }, StringSplitOptions.None));
            
            DialogResult result = MessageBox.Show("are you want display each execute step by step? ","Question",MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            
            bool PrintEachStep=false;
            int StartPoint=10;

            clsMachineSimulator machineSimulator = new clsMachineSimulator(16, 256);
            Instructions = ProccessingListOfInstructions(Instructions);
            
            if(Convert.ToInt16(mtbStartPoint.Text) %2== 0)
                StartPoint= Convert.ToInt16(mtbStartPoint.Text);

            machineSimulator.Load(Instructions,StartPoint);
            machineSimulator.Execute();
             
            if (result == DialogResult.No)
                PrintEachStep = false;
             else
                PrintEachStep = true;

            DisplayResults displayResults = new DisplayResults(machineSimulator.GetZeroCellTable(),PrintEachStep, machineSimulator.GetMemoryTable(), machineSimulator.GetRegistersTable(), machineSimulator.GetPC(), machineSimulator.GetIR());
            displayResults.Show();
        }

        private void btClear_Click(object sender, EventArgs e)
        {
            tbIstructions.Text= string.Empty;
        }

        private void btExist_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mtbStartPoint_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
           
                MessageBox.Show("Enter a decimal value from 0 to 254", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information); 
        }
    }
}
