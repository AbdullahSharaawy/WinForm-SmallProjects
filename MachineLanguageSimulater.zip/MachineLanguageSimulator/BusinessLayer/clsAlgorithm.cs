﻿using Microsoft.SqlServer.Server;
using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
namespace BusinessLayer
{
    class Memory
    {
        private List<string> memory;

        public Memory(int size)
        {
            memory = new List<string>(new string[size]);
            for (int i = 0; i < size; i++) memory[i] = "00";
        }
        public void LoadToMemory(List<string> instructions)
        {
            int address = 10;
            foreach (var instr in instructions)
            {
                if (instr.Length == 4 && IsAllHexDigits(instr))
                {
                    Store(address, instr);
                    address += 2; // Move to the next address (assuming 2 units per instruction)
                    
                    if(instr=="C000")
                        break;
                }
                
            }
        }
        private bool IsAllHexDigits(string instr)
        {
            foreach (char c in instr)
            {
                if (!IsHexDigit(c))
                {
                    return false; // Found a non-hex digit
                }
            }
            return true; // All characters are hex digits
        }

        private bool IsHexDigit(char c)
        {
            return Uri.IsHexDigit(c); // Check if the character is a valid hex digit
        }
        //private void completeToFourDigits(ref string value)
        //{
        //    if (value.Length == 1)
        //        value = "000" + value;
        //    else if (value.Length == 2)
        //        value = "00" + value;
        //    else if (value.Length == 3)
        //        value = "0" + value;
        //}
        public void Store(int address, string value)
        {
            
            if (address >= 0 && address < 256)
            {
                memory[address] = value.Substring(0, 2);
                if(value.Length==4)// to skip any error only
                memory[address + 1] = value.Substring(2, 2);
            }
        }

        public string Load(int address)
        {
            if (address >= 0 && address < 256)
            {
                return memory[address] + memory[address + 1];
            }
            return "0000";
        }

        public List<string> GetMemoryData()
        {
            return memory;
        }
    }

    class Register
    {
        private List<string> registers;

        public Register(int numRegisters)
        {
            registers = new List<string>(new string[numRegisters]);
            for (int i = 0; i < numRegisters; i++) registers[i] = "00";
        }

        public void Set(int index, string value)
        {
            if (index >= 0 && index < registers.Count)
            {
                registers[index] = value;
            }
        }

        public string Get(int index)
        {
            if (index >= 0 && index < registers.Count)
            {
                return registers[index];
            }
            return "00";
        }

        public List<string> GetRegistersData()
        {
            return registers;
        }
    }

    

class CU
    {
        private Memory memory;
        private Register register;
        private int pc;

        public CU(ref Memory mem,ref Register regs, ref int programCounter)
        {
            memory = mem;
            register = regs;
            pc = programCounter;
        }

        public void Address(string instr)
        {
            int r = instr[1] - '0';
            string address = instr.Substring(2, 2);
            int addr = Convert.ToInt32(address, 16);

            if (addr < 0 || addr >= 256)
            {
                register.Set(r, "00");
                return;
            }

            string value = memory.Load(addr);
            if (string.IsNullOrEmpty(value))
            {
                register.Set(r, "00");
                return;
            }

            register.Set(r, value.Substring(2, 2));
        }

        public void RecordValue(string instr)
        {
            int r = instr[1] - '0';
            string value = instr.Substring(2, 2);

            register.Set(r, value == "00" ? "00" : value);
        }

        public void Cope(string instr)
        {
            int r = instr[1] - '0';
            string address = instr.Substring(2, 2);
            string value = register.Get(r);

            memory.Store(Convert.ToInt32(address, 16), value);
        }

        public void Move(string instr)
        {
            int r = instr[2] - '0';
            int s = instr[3] - '0';
            string value = register.Get(r);

            register.Set(s, value);
        }

        public  string HexToBinary(ref string hex)
        {
            StringBuilder binary = new StringBuilder();

            if (hex[0] == '0')
                hex = hex.Remove(0, 1);

            foreach (char hexDigit in hex)
            {
                int decimalValue = hexDigit >= '0' && hexDigit <= '9'
                    ? hexDigit - '0'
                    : (hexDigit >= 'A' && hexDigit <= 'F' ? hexDigit - 'A' + 10 : hexDigit - 'a' + 10);

                binary.Append(Convert.ToString(decimalValue, 2).PadLeft(4, '0'));
            }

            return binary.ToString();
        }

        public string BinaryToHex(string binaryStr)
        {
            string paddedBinary = binaryStr.PadLeft(((binaryStr.Length + 3) / 4) * 4, '0');
            StringBuilder hexStream = new StringBuilder();

            for (int i = 0; i < paddedBinary.Length; i += 4)
            {
                string fourBits = paddedBinary.Substring(i, 4);
                int decimalValue = Convert.ToInt32(fourBits, 2);

                hexStream.Append(decimalValue.ToString("X"));
            }

            return hexStream.ToString();
        }

        public void Rotate(string instr)
        {
            int r = instr[1] - '0';
            int noRotate = int.Parse(instr.Substring(2, 2));
            string value = register.Get(r);

            value = HexToBinary(ref value);
            for (int i = 0; i < noRotate; i++)
            {
                char c = value[value.Length - 1];
                value = value.Insert(0,  c+"");
                value = value.Remove(value.Length - 1, 1);
            }

            value = BinaryToHex(value);

            if (value.Length == 1)
                value = "0" + value;

            register.Set(r, value);
        }

        public static string IntegerToHex(int value)
        {
            return value.ToString("X").ToUpper();
        }
        private BitArray LeftShift(BitArray bitArray, int shiftAmount)
        {
            int length = bitArray.Count;

            // Shift each bit right by the shift amount
            for (int i = length - 1; i >= shiftAmount; i--)
            {
                bitArray[i] = bitArray[i - shiftAmount];
            }

            // Set the remaining bits at the beginning to false (0) after the shift
            for (int i = 0; i < shiftAmount; i++)
            {
                bitArray[i] = false;
            }

            return bitArray;
        }

        private BitArray BinaryDouble(double num)
        {
            int count = 0;
            while (num > 0.025)
            {
                num -= 0.025;
                count += 1;
            }
            while (count % 10 != 0)
            {
                count++;
            }
            count /= 10;
            BitArray result = new BitArray(4);
            result=StoreIntegerInSetBits(count,4);
            return result;
        }
        private string BitArrayToString(BitArray bitArray)
        {
            var binaryString = new StringBuilder();
            for (int i = bitArray.Length-1; i >=0 ; i--)
            {
                binaryString.Append(bitArray[i] ? "1" : "0");
            }
            return binaryString.ToString();
        }
        private byte[] NormalizeBits(string value)// accept hexa value only
        {
            // Convert the hex string to an integer, then to a single byte (8 bits)
            int number = Convert.ToInt32(value, 16);
            byte[] byteArray = BitConverter.GetBytes(number);

            // Ensure we're only taking the least significant byte (8 bits)
            byte[] eightBitArray = { byteArray[0] }; // Only keep the first byte
            return eightBitArray;
        }
        private BitArray StoreIntegerInSetBits(int value,int num_bits)
        {
            BitArray result = new BitArray(num_bits);
            for (int bit = 0; bit < num_bits; bit++)
            {
                result[bit] = (value & (1 << bit)) != 0;
            }
            return result;
        }
        private string SumDouble(string Dfir, string Dsec)
        {
            BitArray Df = new BitArray(NormalizeBits(Dfir));
            int sign1 = (Df[7]) ? -1 : 1;
            string moved1 = BitArrayToString(Df);
            
            int move1 = Convert.ToInt32(moved1.Substring(1, 3), 2) - 4;
            
            double mantissa1 = 0.0;
            for (int i = 0; i < 4; i++)
                if (moved1[4 + i] == '1')
                    mantissa1 += Math.Pow(2, -(i + 1));
            double value1 = sign1 * mantissa1 * Math.Pow(2, move1);

           
            // Initialize the BitArray with only the 8 bits
            BitArray Ds = new BitArray(NormalizeBits(Dsec));

            int sign2 = (Ds[7]) ? -1 : 1;
            string moved2 = BitArrayToString(Ds);
            int move2 = Convert.ToInt32(moved2.Substring(1, 3), 2) - 4;
            
            double mantissa2 = 0.0;
            for (int i = 0; i < 4; i++)
                if (moved2[4 + i] == '1')
                    mantissa2 += Math.Pow(2, -(i + 1));
            double value2 = sign2 * mantissa2 * Math.Pow(2, move2);

            double result = value1 + value2;
            string sign3 = "0";
            string final;
            if (result < 0)
            {
                sign3 = "1";
                result *= -1;
            }

            if (result < 1)
            {
                BitArray res = BinaryDouble(result);
                int i = 0;
                while (!res[3])
                {
                    res = LeftShift(res, 1);
                    i++;
                }
                BitArray idi = new BitArray(3);
                idi = StoreIntegerInSetBits(i, 3);
                final = sign3 + BitArrayToString(idi) + BitArrayToString(res);
            }
            else
            {
                double fraction = result - Math.Floor(result);
                double importNum = result - fraction;
                BitArray res2 = BinaryDouble(fraction);
                BitArray res1 = new BitArray(4);
                res1=StoreIntegerInSetBits((int)importNum, 4);
                int index = 0;
                int j = 3;
                while (!res1[j])
                {
                    index++;
                    j--;
                }
                index = -(index - 4) + 4;
                while (!res1[3])
                    res1 = LeftShift(res1, 1);
                for (int i = 3; i > 0; i--)
                {
                    if (res2[3]) break;
                    res2 = LeftShift(res2, 1);
                }
                int k = 0;
                while (!res1[k])
                {
                    if (res2[3])
                    {
                        res1[k] = true;
                    }
                    res2 = LeftShift(res2, 1);
                    k++;
                }
                BitArray idi = new BitArray(3);
                idi = StoreIntegerInSetBits(index, 3);
                final = sign3 + BitArrayToString(idi) + BitArrayToString(res1);
            }
            int finaly = Convert.ToInt32(final, 2);
            return finaly.ToString("X");
        }

        public void SumFloating(string instr)
        {
            int r = instr[1] - '0';
            int s = instr[2] - '0';
            int t = instr[3] - '0';
            string valueS = register.Get(s);
            string valueT = register.Get(t);
            string result = SumDouble(valueS, valueT);
            register.Set(r, result);
        }

        public void SumTwoComplement(string instr)
        {
            int r = instr[1] - '0';
            int s = instr[2] - '0';
            int t = instr[3] - '0';

            int valueS = Convert.ToInt32(register.Get(s), 16);
            if (valueS > 127) valueS -= 256;

            int valueT = Convert.ToInt32(register.Get(t), 16);
            if (valueT > 127) valueT -= 256;

            int result = valueS + valueT;

            if (result < 0)
                result += 256;
            else if (result > 255)
                result = 255;

            string stringResult = IntegerToHex(result);
            register.Set(r, stringResult.Length == 1 ? "0" + stringResult : stringResult);
        }
        public void AND(string instr)
        {
            int r = instr[1] - '0';
            int s = instr[2] - '0';
            int t = instr[3] - '0';

            int valueS = Convert.ToInt32(register.Get(s), 16);
            int valueT = Convert.ToInt32(register.Get(t), 16);
            int resultAnd = valueS & valueT;

            if (resultAnd > 255) resultAnd = 255;

            string stringResult = IntegerToHex(resultAnd);
            register.Set(r, stringResult.Length == 1 ? "0" + stringResult : stringResult);
        }

        public void XOR(string instr)
        {
            int r = instr[1] - '0';
            int s = instr[2] - '0';
            int t = instr[3] - '0';

            int valueS = Convert.ToInt32(register.Get(s), 16);
            int valueT = Convert.ToInt32(register.Get(t), 16);
            int resultXor = valueS ^ valueT;

            if (resultXor > 255) resultXor = 255;

            string stringResult = IntegerToHex(resultXor);
            register.Set(r, stringResult.Length == 1 ? "0" + stringResult : stringResult);
        }

        public void OR(string instr)
        {
            int r = instr[1] - '0';
            int s = instr[2] - '0';
            int t = instr[3] - '0';

            int valueS = Convert.ToInt32(register.Get(s), 16);
            int valueT = Convert.ToInt32(register.Get(t), 16);
            int resultOr = valueS | valueT;

            if (resultOr > 255) resultOr = 255;

            string stringResult = IntegerToHex(resultOr);
            register.Set(r, stringResult.Length == 1 ? "0" + stringResult : stringResult);
        }

        public void Jump(string instr)
        {
            int r = instr[1] - '0';
            string address = instr.Substring(2, 2);

            if (register.Get(r) == register.Get(0))
            {
                pc = Convert.ToInt32(address, 16) - 2;
            }
        }

        public void JumpUp(string instr)
        {
            int r = instr[1] - '0';
            string address = instr.Substring(2, 2);

            if (register.Get(r).CompareTo(register.Get(0)) > 0)
            {
                pc = Convert.ToInt32(address, 16) - 2;
            }
        }

        
    }

    public class clsMachineSimulator
    {
        private bool halted;
        private int pc;
        private string instruction;
        private Memory memory;
        private CU cu;
        private Register register;
        private DataTable MemoryTable;
        private DataTable RegisterTable;
             
        public DataTable GetRegistersTable()
        {
            return RegisterTable;
        }
        public DataTable GetMemoryTable()
        {
            return MemoryTable;
        }
        public int GetPC()
        {
            return pc;
        }
        public string GetIR()
        {
            return instruction;
        }

        public clsMachineSimulator(int regSize, int memorySize)
        {
            halted = false;
            pc = 0;
            instruction = "0000";
            register = new Register(regSize);
            memory = new Memory(memorySize);
            cu=new CU(ref memory,ref register,ref pc);
        }

        public void Load(List<string> instructions)// LOAD ALL INSTRUCTIONS TO MEMORY
        {
            memory.LoadToMemory(instructions);
        }

        public void Execute()
        {
            while (!halted)
            {
                instruction = memory.Load(pc);
                if (string.IsNullOrEmpty(instruction))
                {
                    break;
                }
                ExecuteInstruction(instruction);
                pc += 2;
            }

        }

        private void ExecuteInstruction(string instr)
        {
            char opCode = instr[0];

            switch (opCode)
            {
                case '1':
                    cu.Address(instr);
                    break;
                case '2':
                    cu.RecordValue(instr);
                    break;
                case '3':
                    cu.Cope(instr);
                    break;
                case '4':
                    cu.Move(instr);
                    break;
                case '5':
                    cu.SumTwoComplement(instr);
                    break;
                case '6':
                    cu.SumFloating(instr);
                    break;

                case '7':
                    cu.OR(instr);
                    break;
                case '8':
                    cu.AND(instr);
                    break;
                case '9':
                    cu.XOR(instr);
                    break;
                case 'B':
                    cu.Jump(instr);
                    break;
                case 'D':
                    cu.JumpUp(instr);
                    break;
                case 'A':
                    cu.Rotate(instr);
                    break;
                case 'C':
                    halted = true;
                  MemoryTable=  CreateMemoryTable(memory.GetMemoryData());
                  RegisterTable= CreateRegistersTable(register.GetRegistersData());
                    break;

                default:
                    break;
            }
        }

       

        private DataTable CreateMemoryTable(List<string>memory)
        {
            // Create a new DataTable
            DataTable table = new DataTable();

            // Define columns
            table.Columns.Add(" ", typeof(string));

            for (int i = 0; i<16; i++)
            {
                table.Columns.Add(CU.IntegerToHex(i), typeof(string));
            }

            // Add some rows
            Int16 counter = 0;
            for (int i = 0; i < 16; i++)
            {

                table.Rows.Add(CU.IntegerToHex(i), memory[counter], memory[counter+1], memory[counter+2], memory[counter+3], memory[counter+4], memory[counter+5], memory[counter+6], memory[counter+7], memory[counter+8], memory[counter+9], memory[counter+10], memory[counter+11], memory[counter+12], memory[counter+13], memory[counter+14], memory[counter+15]);
                counter += 16;
                
            }

            return table;
        }
        private DataTable CreateRegistersTable(List<string> register)
        {
            // Create a new DataTable
            DataTable table = new DataTable();

            // Define columns
            table.Columns.Add("Register", typeof(string));

            table.Columns.Add("Value", typeof(string));
            

            // Add some rows
            
            for (int i = 0; i < 16; i++)
            {

                table.Rows.Add(CU.IntegerToHex(i), register[i]);
             
            }

            return table;
        }
    }

}
