﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RGB
{
    public partial class RGB_Control : UserControl
    {
        public RGB colors;
        public event EventHandler<RGB> ColorChanged;
        public class RGB
        {
            public int Red { get; set; }
            public int Green { get; set; }
            public int Blue { get; set; }
        }
        public RGB_Control()
        {
            InitializeComponent();
            colors = new RGB();
            tbBlue.Scroll += RGB_Control_Scroll;
            tbGreen.Scroll += RGB_Control_Scroll;
            tbRed.Scroll += RGB_Control_Scroll;
        }

       

        private void RGB_Control_Scroll(object sender, EventArgs e)
        {
            try
            {
                colors.Red = (int)tbRed.Value;
                colors.Blue = (int)tbBlue.Value;
                colors.Green = (int)tbGreen.Value;
                pRGB.BackColor = Color.FromArgb(colors.Red,colors.Green,colors.Blue);
                ColorChanged?.Invoke(this,colors);
            }
            catch { }
        }
    }
}
