﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RGB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void rgB_Control1_ColorChanged(object sender, RGB_Control.RGB e)
        {
            lbBlue.Text=e.Blue.ToString();
            lbGreen.Text=e.Green.ToString();
            lbRed.Text=e.Red.ToString();
        }
    }
}
