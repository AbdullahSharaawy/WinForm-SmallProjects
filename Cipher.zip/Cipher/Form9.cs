﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
           
        }
        private string original_text = "", new_text = "", key = "12345";//initial value;
        private bool input_key=false;
        private char [,]matrix = new char[6,6];
        private void btReset_Click(object sender, EventArgs e)
        {
            original_text = "";
            new_text = "";
            input_key = false;
            tbEncryptedText.Text = "";
            tbOriginalText.Text = "";

            maskedTextBox1.Text = "";
        }

        private void CipherText(  )
        {
            string cipher_text = "";
            bool found = false;

            //this loop to convert the character to digit
            for (int i = 0; i < original_text.Length; i++)
            {
                found = false;
                //this condition to ignore any space or digit or punctuation
                if (char.IsDigit(original_text[i]) || char.IsWhiteSpace(original_text[i]) || char.IsPunctuation(original_text[i]))
                {
                    cipher_text += original_text[i];
                }
                else
                {
                    for (int r = 0; r < 6; r++)
                    {
                        for (int c = 0; c < 6; c++)
                        {
                            if (char.ToUpper(original_text[i]) == matrix[r,c])
                            {
                                cipher_text += matrix[r,0];
                                cipher_text += matrix[0,c];
                                found = true;
                                break;
                            }
                            //the position of I is same position of J
                            else if (char.ToUpper(original_text[i]) == 'J')
                            {
                                cipher_text += matrix[2,0];
                                cipher_text += matrix[0,4];
                                found = true;
                                break;
                            }
                        }
                        if (found) break;
                    }
                }
            }
            new_text= cipher_text;
        }
        //this function to Decryption text
        private void DecipherText( )
        {
            string decipher_text = "";
            //sub text is variable to store each two digit to decipher them
            int sub_text, first_digit, second_digit;
            //this loop to check on all characters in the text and decipher each two digit
            for (int i = 0; i < original_text.Length; i += 2)
            {
                //this condition to ignore any space or character or punctuation
                if (char.IsWhiteSpace(original_text[i]) || char.IsPunctuation(original_text[i]) || char.IsLetter(original_text[i]))
                {
                    decipher_text += original_text[i];
                    i -= 1;
                }

                else
                {
                    sub_text = (Convert.ToInt16(original_text.Substring(i, 2)));
                    first_digit = sub_text / 10;
                    second_digit = sub_text % 10;
                    //this loop to decipher each two digit 
                    //each two digit express about one character 
                    for (int c = 0; c < 6; c++)
                    {
                        if (second_digit == (matrix[0,c] - '0'))
                        {
                            for (int r = 0; r < 6; r++)
                            {
                                if (first_digit == (matrix[r,0] - '0'))
                                {
                                    //r is sympol for number row that equal first character that exist in sub_text
                                    //c is sympol for number row that equal second character that exist in sub_text
                                    decipher_text += matrix[r,c];
                                    break;
                                }
                            }
                        }
                    }

                }
            }
            new_text = decipher_text;
        }

        private void btDecrypt_Click(object sender, EventArgs e)
        {
            PreparingForm();

            if (!input_key )
                MessageBox.Show("You Must Enter a Key from five digits!", "message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {

                original_text = tbEncryptedText.Text;
                new_text = "";


                DecipherText();
                tbOriginalText.Text = new_text;
            }
            
        }

        private void btEncrypt_Click(object sender, EventArgs e)
        {
            PreparingForm();

            if (!input_key )
                MessageBox.Show("You Must Enter a Key from five digits!", "message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {
                new_text = "";
                original_text = tbOriginalText.Text;
                CipherText();
                tbEncryptedText.Text = new_text;

            }

            
        }

        private void PreparingForm()
        {
            
            if(maskedTextBox1.Text.Length != 5 )
            {
                input_key = false;    
            }
                
            else
            {
                input_key = true;
                key = maskedTextBox1.Text;
            }
                
            InitializeMatrix();
        }

        private void InitializeMatrix()
        {
            char[,] Matrix ={
                { ' ',key[0],key[1],key[2],key[3],key[4]},
                       { key[0],'A',   'B',   'C',   'D',   'E'},
                       { key[1],'F',   'G',   'H',   'I',   'K'},
                       { key[2],'L',   'M',   'N',   'O',   'P'},
                       { key[3],'Q',   'R',   'S',   'T',   'U'},
                       { key[4],'V',   'W',   'X',   'Y',   'Z'}
            };
            for (short i = 0; i < 6; i++)
            {
                for (short j = 0; j < 6; j++)
                {
                    matrix[i, j] = Matrix[i, j];
                }
            }
        }
       

       

        private void Form9_Paint(object sender, PaintEventArgs e)
        {
            Color White = Color.FromArgb(255, 255, 255, 255);

            Pen Pen = new Pen(White);
            Pen.Width = 10;


            Pen.StartCap = System.Drawing.Drawing2D.LineCap.Round;
            Pen.EndCap = System.Drawing.Drawing2D.LineCap.Round;

            // Draw Line vertical

            e.Graphics.DrawLine(Pen, 600, 70, 600, 400);
        }
    }
}
