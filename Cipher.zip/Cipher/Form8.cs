﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }
        private string original_text = "", new_text = "";
        private void Form8_Paint(object sender, PaintEventArgs e)
        {
            Color White = Color.FromArgb(255, 255, 255, 255);

            Pen Pen = new Pen(White);
            Pen.Width = 10;


            Pen.StartCap = System.Drawing.Drawing2D.LineCap.Round;
            Pen.EndCap = System.Drawing.Drawing2D.LineCap.Round;

            // Draw Line vertical

            e.Graphics.DrawLine(Pen, 600, 70, 600, 400);
        }

    private void  CipherText()
{
   
    for(int i=0 ; i<original_text.Length ; i++)
    {

      if(char.ToUpper(original_text[i])=='A')        new_text+="aaaaa";
      else if (char.ToUpper(original_text[i]) == 'B')new_text+="aaaab";
      else if (char.ToUpper(original_text[i]) =='C') new_text+="aaaba";
        else if (char.ToUpper(original_text[i])=='E')new_text+="aabaa";
        else if (char.ToUpper(original_text[i])=='F')new_text+="aabab";
        else if (char.ToUpper(original_text[i])=='G')new_text+="aabba";
        else if (char.ToUpper(original_text[i])=='H')new_text+="aabbb";
        else if (char.ToUpper(original_text[i])=='I')new_text+="abaaa";
        else if (char.ToUpper(original_text[i])=='J')new_text+="abaab";
        else if (char.ToUpper(original_text[i])=='K')new_text+="ababa";
        else if (char.ToUpper(original_text[i])=='L')new_text+="ababb";
        else if (char.ToUpper(original_text[i])=='M')new_text+="abbaa";
        else if (char.ToUpper(original_text[i])=='N')new_text+="abbab";
        else if (char.ToUpper(original_text[i])=='O')new_text+="abbba";
        else if (char.ToUpper(original_text[i])=='P')new_text+="abbbb";
        else if (char.ToUpper(original_text[i])=='Q')new_text+="baaaa";
        else if (char.ToUpper(original_text[i])=='R')new_text+="baaab";
        else if (char.ToUpper(original_text[i])=='S')new_text+="baaba";
        else if (char.ToUpper(original_text[i])=='T')new_text+="baabb";
        else if (char.ToUpper(original_text[i])=='U')new_text+="babaa";
        else if (char.ToUpper(original_text[i])=='V')new_text+="babab";
        else if (char.ToUpper(original_text[i])=='W')new_text+="babba";
      else if (char.ToUpper(original_text[i]) == 'X')new_text+="babbb";
      else if (char.ToUpper(original_text[i]) == 'Y')new_text+="bbaaa";
      else if (char.ToUpper(original_text[i]) == 'D')new_text+="aaabb";
      else if (char.ToUpper(original_text[i]) =='Z') new_text+="bbaab";
       else new_text+=original_text[i];
    }
    
}

 private void  DecipherText( )
{
    string five_characters="";
    int n_char=original_text.Length;
    while(true)
    {
        if(original_text=="")break;
        else if(!char.IsLetter(original_text[0]))
        {
            new_text+=original_text[0];
           original_text= original_text.Remove(0,1);
            continue;
        }
        five_characters+=original_text.Substring(0,5);
        original_text = original_text.Remove(0,5);
                if (five_characters == "aaaaa") new_text += 'A';
                else if (five_characters=="aaaab")new_text+='B';
        else if (five_characters=="aaaba")new_text+='C';
        else if (five_characters=="aaabb")new_text+='D';
        else if (five_characters=="aabaa")new_text+='E';
        else if (five_characters=="aabab")new_text+='F';
        else if (five_characters=="aabba")new_text+='G';
        else if (five_characters=="aabbb")new_text+='H';
        
        else if (five_characters=="abaaa")new_text+='I';
        else if (five_characters=="abaab")new_text+='J';
        else if (five_characters=="ababa")new_text+='K';
        else if (five_characters=="ababb")new_text+='L';
        else if (five_characters=="abbaa")new_text+='M';
        else if (five_characters=="abbab")new_text+='N';
        else if (five_characters=="abbba")new_text+='O';
        else if (five_characters=="abbbb")new_text+='P';
        else if (five_characters=="baaaa")new_text+='Q';
        else if (five_characters=="baaab")new_text+='R';
        else if (five_characters=="baaba")new_text+='S';
        else if (five_characters=="baabb")new_text+='T';
        else if (five_characters=="babaa")new_text+='U';
        else if (five_characters=="babab")new_text+='V';
        else if (five_characters=="babba")new_text+='W';
        else if (five_characters=="babbb")new_text+='X';
        else if (five_characters=="bbaaa")new_text+='Y';
        else if (five_characters=="bbaab")new_text+='Z';
        five_characters="";
    }
  
}
       

       

        private void btReset_Click(object sender, EventArgs e)
        {
            original_text = "";
            new_text = "";

            tbEncryptedText.Text = "";
            tbOriginalText.Text = "";

            tbOriginalText.ReadOnly = false;
            tbEncryptedText.ReadOnly = false;
        }

        private void btDecrypt_Click(object sender, EventArgs e)
        {
            

            original_text = tbEncryptedText.Text;
            new_text = "";


            DecipherText();
            tbOriginalText.Text = new_text;
        }

        private void btEncrypt_Click(object sender, EventArgs e)
        {
            original_text = "";
            new_text = "";

           

            original_text = tbOriginalText.Text;
            CipherText();
            tbEncryptedText.Text = new_text;
        }

       

        
    }
}
