﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

       
       

        private void lbAtbash_Click_1(object sender, EventArgs e)
        {
            Form form = new Form2();
            form.ShowDialog();
        }

        private void lbBaconian_Click(object sender, EventArgs e)
        {
            Form form = new Form8();
            form.ShowDialog();
        }

        private void lbPolybiusSquare_Click(object sender, EventArgs e)
        {
            Form form = new Form9();
            form.ShowDialog();
        }

        private void lbRail_Fence_Click(object sender, EventArgs e)
        {
            Form form = new Form10();
            form.ShowDialog();
        }
    }
}
