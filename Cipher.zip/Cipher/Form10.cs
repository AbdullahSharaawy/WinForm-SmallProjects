﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
        }

        private string original_text="", new_text="",view="";
        private char[][] matrix;
        private int key=0;
        private int n_columns=0; // Assuming n_columns is defined elsewhere
        private bool input_key = false;

        private void InitializeMatrix()
        {
            

            matrix = new char[key][];
            for (int i = 0; i < key; i++)
            {
                matrix[i] = new char[n_columns];
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        { 

                key = 3;
                input_key = true;
                
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
                key = 4;
                input_key = true;
               
        }
    private    void InputMatrixWithStars()
        {
            short counter = 0, sign = 1;
            int index = 0, R = 0;
            matrix[0][0] = '*';
            for (int c = 0; c < n_columns; c++)
            {
                if (R == 0 && c == 0) continue;
                else if ((++counter) == key )
                {
                    sign *= -1;
                    counter = 1;
                }
                R = R + sign * 1;
                matrix[R][c] = '*';
            }
            //this loop to store space in any cell is not has star as character
            for (int r = 0; r < key ; r++)
            {
                for (int c = 0; c < n_columns; c++)
                {
                    if (matrix[r][c] != '*')
                        matrix[r][c] = '-';
                }

            }

        }
        private string ProcessingText( string original_text_c)
        {
            string new_text = "";
            for (int i = 0; i < original_text.Length; i++)
            {
                if (char.IsWhiteSpace(original_text_c[i]) || char.IsDigit(original_text_c[i]) || char.IsPunctuation(original_text_c[i])) continue;
                new_text += original_text_c[i];
            }
            return new_text;
        }
        //this function to Input Matrix With Characters as diagonal column by column
        private   void InputMatrixWithCharactersV1(string original_text_c)
        {
            int index = 0;
            for (int c = 0; c < n_columns; c++)
            {
                for (int r = 0; r < key ; r++)
                {
                    if (matrix[r][c] == '*')
                    {
                        matrix[r][c] = original_text_c[index];
                        index++;
                    }
                }
            }
        }
        //this function to Input Matrix With Characters as diagonal row by row
      private  void InputMatrixWithCharactersV2(string original_text_c)
        {
            int index = 0;
            for (int r = 0; r < key ; r++)
            {
                for (int c = 0; c < n_columns; c++)

                {
                    if (matrix[r][c] == '*')
                    {
                        matrix[r][c] =original_text_c[index];
                        index++;
                    }
                }
            }
        }
        //this function to cipher Text
        private void CipherText(string original_text_c)
        {
            InputMatrixWithStars();
            InputMatrixWithCharactersV1(original_text_c);
            
            for (int r = 0; r < key ; r++)
            {
                for (int c = 0; c < n_columns; c++)
                {
                    if (char.IsLetter(matrix[r][c]))
                    {
                        new_text += matrix[r][c];
                    }
                }
            }

            
        }
        //this function to Decipher Text 
      private void  DecipherText(string original_text_c)
        {
            InputMatrixWithStars();
            InputMatrixWithCharactersV2(original_text_c);
            
            for (int c = 0; c < n_columns; c++)
            {
                for (int r = 0; r < key ; r++)
                {
                    if (char.IsLetter(matrix[r][c]))
                    {
                        new_text += matrix[r][c];
                    }
                }
            }

            
        }

        private void btEncrypt_Click(object sender, EventArgs e)
        {

            if (!input_key || (key != 3 && key != 4))
                MessageBox.Show("You Must Choose the Key!", "message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {
                lbview.Text = "";
                view = "";
                new_text = "";
                original_text = tbOriginalText.Text;
                n_columns=ProcessingText(original_text).Length;
                InitializeMatrix();
                CipherText(ProcessingText(original_text));
                tbEncryptedText.Text = new_text;
                print_matrix();
                lbview.Text = view;
            }

        }

        private void btDecrypt_Click(object sender, EventArgs e)
        {
            if (!input_key || (key != 3 && key != 4))
                MessageBox.Show("You Must Choose the Key!", "message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {

                lbview.Text = "";
                view = "";
                 new_text = "";
                original_text = tbEncryptedText.Text;

                n_columns = original_text.Length;
                InitializeMatrix();
                
                DecipherText(ProcessingText(original_text));
                tbOriginalText.Text = new_text;
                print_matrix();
                lbview.Text = view;

            }
        }

        private void btReset_Click(object sender, EventArgs e)
        {
            original_text = "";
            new_text = "";

            tbEncryptedText.Text = "";
            tbOriginalText.Text = "";

            tbOriginalText.ReadOnly = false;
            tbEncryptedText.ReadOnly = false;
        }

        private void Form10_Load(object sender, EventArgs e)
        {
          

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

       
       private void print_matrix( )
        {
            n_columns = ProcessingText(original_text).Length;
            
            for (int r = 0; r < key ; r++)
            {
                for (int c = 0; c < n_columns; c++)
                {
                    view += "  " + matrix[r][c] + "  ";
                }
                view+="\n";
            }
           
        }
    }
}
