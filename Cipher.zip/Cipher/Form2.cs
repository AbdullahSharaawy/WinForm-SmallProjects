﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form 
    {
       private string original_text="", new_text="";
        public Form2()
        {
            InitializeComponent();
        }

       
        private void Form2_Paint(object sender, PaintEventArgs e)
        {
            Color White = Color.FromArgb(255, 255, 255, 255);

            Pen Pen = new Pen(White);
            Pen.Width = 10;


            Pen.StartCap = System.Drawing.Drawing2D.LineCap.Round;
            Pen.EndCap = System.Drawing.Drawing2D.LineCap.Round;

            // Draw Line vertical

            e.Graphics.DrawLine(Pen, 600, 70, 600, 400);
            
        }

       
       
//The Atbash cipher is a very common, simple cipher. Basically, when encoded, an "A" becomes a "Z", "B" turns into "Y", etc.
//Plain: ABCDEFGHIJKLMNOPQRSTUVWXYZ ,Cipher: ZYXWVUTSRQPONMLKJIHGFEDCBA  
//this Funcion to do all previous notes 
private void  CipherText( )
{
    
            for (int i = 0; i < original_text.Length; i++)
            {
                if (Char.IsDigit(original_text[i]) || Char.IsPunctuation(original_text[i]) || Char.IsWhiteSpace(original_text[i]))
        {
            continue;
        }
        else
        {
                    //convert any small character to capital
                original_text=    original_text.Replace(original_text[i], Char.ToUpper(original_text[i])) ;
            new_text += ((char)('Z' - (original_text[i] - 'A')));
        }
            }
    
}

        private void btEncrypt_Click(object sender, EventArgs e)
        {
            original_text = "";
            new_text = "";

           

            original_text = tbOriginalText.Text;
            CipherText();
            tbEncryptedText.Text = new_text;
        }

        private void btReset_Click(object sender, EventArgs e)
        {
            original_text = "";
            new_text = "";

            tbEncryptedText.Text = "";
            tbOriginalText.Text = "";

            tbOriginalText.ReadOnly = false;
            tbEncryptedText.ReadOnly = false;
        }

        private void btDecrypt_Click(object sender, EventArgs e)
        {

            original_text = tbEncryptedText.Text;
            new_text = "";
            

            CipherText();
            tbOriginalText.Text = new_text;
        }

        

   
}


       
    }

