﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1.Properties;

namespace WindowsFormsApp1
{
    
    public partial class Form1 : Form
    {
        private char[] board = new char[9];
        private decimal turn = 1;
          private short  winer=0;
        private void initialize_array()
        {
            for (int i = 0; i < board.Length; i++)
            {
                board[i] = ' ';
            }
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Color White = Color.FromArgb(255, 255, 255, 255);

            Pen Pen = new Pen(White);
            Pen.Width = 10;

            
            Pen.StartCap = System.Drawing.Drawing2D.LineCap.Round;
            Pen.EndCap = System.Drawing.Drawing2D.LineCap.Round;

            // Draw Line horizontal
          
            e.Graphics.DrawLine(Pen, 300, 250, 870, 250);
            e.Graphics.DrawLine(Pen, 300, 400, 870, 400);
          
            // Draw line vertical
            e.Graphics.DrawLine(Pen, 460, 130, 460, 530);
            e.Graphics.DrawLine(Pen, 700, 130, 700, 530);
            


        }
        private bool Draw()
        {
            for(short i=0; i < board.Length; i++)
            {
                if(board[i] == ' ')
                    return false;
            }
            if (winer == 0)

            {
                return true;
            }
            return false;
         }

        private bool WhoWon()
        {
            //check for all rows
            for (short i = 1; i < 8; i += 3)
            {
                if (board[i] - board[i - 1] == 0 && board[i + 1] - board[i] == 0 && board[i] != ' ')
                {
                    if (board[i] == 'x') winer = 1;
                    else winer = 2;
                    if (i == 1)
                    {
                        pictureBox2.BackColor = Color.Red;
                        pictureBox1.BackColor = Color.Red;
                        pictureBox3.BackColor = Color.Red;

                    }
                    else if (i == 4)
                    {
                        pictureBox7.BackColor = Color.Red;
                        pictureBox8.BackColor = Color.Red;
                        pictureBox9.BackColor = Color.Red;

                    }
                    else
                    {
                        pictureBox12.BackColor = Color.Red;
                        pictureBox10.BackColor = Color.Red;
                        pictureBox11.BackColor = Color.Red;


                    }
                    return true;
                }
            }
            // check for all columns
            for (short i = 3; i < 6; i ++)
            {
                if (board[i] - board[i - 3] == 0 && board[i + 3] - board[i] == 0 && board[i]!= ' ')
                {
                    if (board[i] == 'x') winer = 1;
                    else winer = 2;
                    
                    if (i == 3)
                    {
                        pictureBox1.BackColor = Color.Red;
                        pictureBox7.BackColor = Color.Red;
                        pictureBox10.BackColor = Color.Red;

                    }
                    else if (i == 4)
                    {
                        pictureBox2.BackColor = Color.Red;
                        pictureBox8.BackColor = Color.Red;
                        pictureBox11.BackColor = Color.Red;

                    }
                    else
                    {
                        pictureBox12.BackColor = Color.Red;
                        pictureBox9.BackColor = Color.Red;
                        pictureBox2.BackColor = Color.Red;


                    }
                    return true;
                }
            }
            //check for two diagonal
            if (board[4] - board[0]==0 && board[8] - board[4]==0 && board[4]!= ' ')
            {
                if (board[4] == 'x') winer = 1;
                else winer = 2;
                pictureBox8.BackColor = Color.Red;
                pictureBox1.BackColor = Color.Red;
                pictureBox12.BackColor = Color.Red;
                return true;
            }
            if (board[4] - board[2] == 0 && board[6] - board[4] == 0 && board[4]!= ' ')
            {
                if (board[4] == 'x') winer = 1;
                else winer = 2;
                pictureBox8.BackColor = Color.Red;
                pictureBox3.BackColor = Color.Red;
                pictureBox10.BackColor = Color.Red;
                return true;
            }
            return false;
        }
        private void StopGame()
        {
            pictureBox1.Enabled = false;
            pictureBox2.Enabled = false;
            pictureBox3.Enabled = false;
            pictureBox7.Enabled = false;
            pictureBox8.Enabled = false;
            pictureBox9.Enabled = false;
            pictureBox10.Enabled = false;
            pictureBox11.Enabled = false;
            pictureBox12.Enabled = false;
            
        }
        private void StartGame()
        {
            pictureBox1.Enabled = true;
            pictureBox2.Enabled = true;
            pictureBox3.Enabled = true;
            pictureBox7.Enabled = true;
            pictureBox8.Enabled = true;
            pictureBox9.Enabled = true;
            pictureBox10.Enabled = true;
            pictureBox11.Enabled = true;
            pictureBox12.Enabled = true;

        }
        private void update_turn()
        {
            labelTurn.Text = "Player" + turn.ToString();
        }
        private void update_board(short index,PictureBox sendor)
        {
            

            

            if (board[index] == ' ')
            {
                if (turn == 1)
                {
                    board[index] = 'x';
                    turn = 2;
                    update_turn();
                    sendor.Image = Resources.X;
                }
                else
                {
                    board[index] = 'o';
                    turn = 1;
                    update_turn();
                    sendor.Image = Resources.O;
                }
            }
            else
            {
                MessageBox.Show("please choose another cell !", "Warning",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
            if (WhoWon())
            {
                labelInProgress.Text = "  player" + winer.ToString();

                MessageBox.Show("Game Over", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                turn = 1;

                StopGame();
            }
            else if(Draw())
            {
                labelInProgress.Text = " Draw";
                MessageBox.Show("Game Over", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                turn = 1;
                StopGame();
            }
                

        }
        
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            update_board(short.Parse(pictureBox1.Tag.ToString()),pictureBox1);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            initialize_array();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            update_board(short.Parse(pictureBox2.Tag.ToString()), pictureBox2);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            update_board(short.Parse(pictureBox3.Tag.ToString()), pictureBox3);
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            update_board(short.Parse(pictureBox7.Tag.ToString()), pictureBox7);
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            update_board(short.Parse(pictureBox8.Tag.ToString()), pictureBox8);
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            update_board(short.Parse(pictureBox9.Tag.ToString()), pictureBox9);
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            update_board(short.Parse(pictureBox10.Tag.ToString()), pictureBox10);
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            update_board(short.Parse(pictureBox11.Tag.ToString()), pictureBox11);
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            update_board(short.Parse(pictureBox12.Tag.ToString()), pictureBox12);
        }

        private void labelInProgress_Click(object sender, EventArgs e)
        {

        }

        

        private void buttonRestart_Click_1(object sender, EventArgs e)
        {
            StartGame();
            update_turn();
            pictureBox1.Image = Resources.question_mark_96;
            pictureBox2.Image = Resources.question_mark_96;
            pictureBox3.Image = Resources.question_mark_96;
            pictureBox7.Image = Resources.question_mark_96;
            pictureBox8.Image = Resources.question_mark_96;
            pictureBox9.Image = Resources.question_mark_96;
            pictureBox10.Image = Resources.question_mark_96;
            pictureBox11.Image = Resources.question_mark_96;
            pictureBox12.Image = Resources.question_mark_96;
            pictureBox1.BackColor = Color.Black;
            pictureBox2.BackColor = Color.Black;
            pictureBox3.BackColor = Color.Black;
            pictureBox7.BackColor = Color.Black;
            pictureBox8.BackColor = Color.Black;
            pictureBox9.BackColor = Color.Black;
            pictureBox10.BackColor = Color.Black;
            pictureBox11.BackColor = Color.Black;
            pictureBox12.BackColor = Color.Black;

            initialize_array();


            labelInProgress.Text = "In Progress";
            winer = 0;
            turn = 1;
        }
    }
}
