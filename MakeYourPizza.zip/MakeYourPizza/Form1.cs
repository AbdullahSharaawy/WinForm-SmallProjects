﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private string Toppings = "", Toppings2 = "",temp;
        private short total_price=0;
       
            private void checkBoxExtraChees_CheckedChanged(object sender, EventArgs e)
        {

            if (checkBoxExtraChees.Checked == true && !Toppings.Contains(" ,Extra Chees"))
            { 
               Toppings += " ,Extra Chees";
                total_price += 5;
            }
            else if (checkBoxExtraChees.Checked == false && Toppings.Contains(" ,Extra Chees"))
            {
                temp = Toppings;
                Toppings = temp.Replace(" ,Extra Chees", "");
                total_price -= 5;
            }
            labelToppings.Text =  Toppings;
            labelPrice.Text = total_price.ToString();
        }

        private void checkBoxTomatoes_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxTomatoes.Checked == true && !Toppings.Contains(" ,Tomatoes"))
            {
                Toppings += " ,Tomatoes";
                total_price += 5;
            }
            else if (checkBoxTomatoes.Checked == false && Toppings.Contains(" ,Tomatoes"))
            {
                temp = Toppings;
                Toppings = temp.Replace(" ,Tomatoes", "");
                total_price -= 5;
            }
            labelToppings.Text =  Toppings;
            labelPrice.Text = total_price.ToString();
        }

        private void checkBoxMushrooms_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxMushrooms.Checked == true && !Toppings.Contains(" ,Mushrooms"))
            {
                Toppings += " ,Mushrooms";
                total_price += 5;
            }
            else if (checkBoxMushrooms.Checked == false && Toppings.Contains(" ,Mushrooms"))
            {
                temp = Toppings;
                Toppings = temp.Replace(" ,Mushrooms", "");
                total_price -= 5;
            }
            labelToppings.Text =Toppings;
            labelPrice.Text = total_price.ToString();
        }

        private void checkBoxOlives_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxOlives.Checked == true && !Toppings2.Contains(" ,Olives"))
            {
                Toppings2 += " ,Olives";
                total_price += 5;
            }
            else if (checkBoxOlives.Checked == false && Toppings2.Contains(" ,Olives"))
            {
                temp = Toppings2;
                Toppings2 = temp.Replace(" ,Olives", "");
                total_price -= 5;
            }
            labelToppings2.Text = Toppings2;
            labelPrice.Text = total_price.ToString();
        }

        private void checkBoxGreenPeppers_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxGreenPeppers.Checked == true && !Toppings.Contains(" ,Green Peppers"))
            {
                Toppings += " ,Green Peppers";
                total_price += 5;
            }
            else if (checkBoxGreenPeppers.Checked == false && Toppings.Contains(" ,Green Peppers"))
            {
                temp = Toppings;
                Toppings = temp.Replace(" ,Green Peppers", "");
                total_price -= 5;
            }
            labelToppings.Text = Toppings;
            labelPrice.Text = total_price.ToString();
        }

        private void checkBoxOnion_CheckedChanged(object sender, EventArgs e)
        {

            if (checkBoxOnion.Checked == true && !Toppings2.Contains(" ,Onion"))
            {
                Toppings2 += " ,Onion";
                total_price += 5;
            }
            else if (checkBoxOnion.Checked == false && Toppings2.Contains(" ,Onion"))
            {
                temp = Toppings2;
                Toppings2 = temp.Replace(" ,Onion", "");
                total_price -= 5;
            }
            
            labelToppings2.Text = Toppings2;
            labelPrice.Text = total_price.ToString();
        }

        private void radioButtonLarge_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonLarge.Checked == true)
            {
                labelSize.Text = "Large";
                total_price += 30;
            }
            else
            {
                total_price -= 30;
            }
            labelPrice.Text = total_price.ToString();
        }

        private void radioButtonSmall_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonSmall.Checked == true)
            {
                labelSize.Text = "Small";
                total_price += 10;
            }
            else
            {
                total_price -= 10;
            }
            labelPrice.Text = total_price.ToString();
        }

        private void radioButtonMedium_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonMedium.Checked == true)
            {
                labelSize.Text = "Medium";
                total_price += 20;
            }
            else
            {
                total_price -= 20;
            }
            labelPrice.Text = total_price.ToString();
        }

       

        private void radioButtonThin_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonThin.Checked == true)
            {
                labelType.Text = "Thin";
                total_price += 10;
            }
            else
            {
                total_price -= 10;
            }
            labelPrice.Text = total_price.ToString();
        }

        private void radioButtonThink_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonThink.Checked == true)
            {
                labelType.Text = "Think";
                total_price +=20;
            }
            else
            {
                total_price -= 20;
            }
            labelPrice.Text = total_price.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           if(MessageBox.Show("Are You Sure ","Order",MessageBoxButtons.OKCancel,MessageBoxIcon.Question,MessageBoxDefaultButton.Button1)==DialogResult.OK)
            {
                groupBox1.Enabled = false;
                groupBox2.Enabled = false;
                groupBox3.Enabled = false;
                groupBox4.Enabled = false;
                button2.Enabled = false;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            groupBox1.Enabled = true;
            groupBox2.Enabled = true;
            groupBox3.Enabled = true;
            groupBox4.Enabled = true;
            button2.Enabled = true;
        }

        private void radioButtonEatIn_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonEatIn.Checked == true)

            {
                labelPlace.Text = "Eat In";
                total_price += 5;
            }
            else
            {
                total_price -= 5;
            }
            labelPrice.Text = total_price.ToString();
        }

        private void radioButtonTakeOut_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonTakeOut.Checked == true)
                labelPlace.Text = "Take Out";

        }
           }
}
