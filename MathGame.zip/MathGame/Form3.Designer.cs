﻿namespace WindowsFormsApp1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbResult = new System.Windows.Forms.Label();
            this.lbNQ = new System.Windows.Forms.Label();
            this.lbLevel = new System.Windows.Forms.Label();
            this.lbType = new System.Windows.Forms.Label();
            this.lbRightAnswers = new System.Windows.Forms.Label();
            this.lbWrongAnswers = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbResult
            // 
            this.lbResult.AutoSize = true;
            this.lbResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbResult.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lbResult.Location = new System.Drawing.Point(10, 23);
            this.lbResult.Name = "lbResult";
            this.lbResult.Size = new System.Drawing.Size(66, 24);
            this.lbResult.TabIndex = 0;
            this.lbResult.Text = "label1";
            // 
            // lbNQ
            // 
            this.lbNQ.AutoSize = true;
            this.lbNQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNQ.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lbNQ.Location = new System.Drawing.Point(10, 84);
            this.lbNQ.Name = "lbNQ";
            this.lbNQ.Size = new System.Drawing.Size(66, 24);
            this.lbNQ.TabIndex = 1;
            this.lbNQ.Text = "label1";
            // 
            // lbLevel
            // 
            this.lbLevel.AutoSize = true;
            this.lbLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLevel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lbLevel.Location = new System.Drawing.Point(10, 145);
            this.lbLevel.Name = "lbLevel";
            this.lbLevel.Size = new System.Drawing.Size(66, 24);
            this.lbLevel.TabIndex = 2;
            this.lbLevel.Text = "label1";
            // 
            // lbType
            // 
            this.lbType.AutoSize = true;
            this.lbType.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lbType.Location = new System.Drawing.Point(10, 206);
            this.lbType.Name = "lbType";
            this.lbType.Size = new System.Drawing.Size(66, 24);
            this.lbType.TabIndex = 3;
            this.lbType.Text = "label1";
            // 
            // lbRightAnswers
            // 
            this.lbRightAnswers.AutoSize = true;
            this.lbRightAnswers.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRightAnswers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lbRightAnswers.Location = new System.Drawing.Point(10, 267);
            this.lbRightAnswers.Name = "lbRightAnswers";
            this.lbRightAnswers.Size = new System.Drawing.Size(66, 24);
            this.lbRightAnswers.TabIndex = 4;
            this.lbRightAnswers.Text = "label1";
            // 
            // lbWrongAnswers
            // 
            this.lbWrongAnswers.AutoSize = true;
            this.lbWrongAnswers.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbWrongAnswers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lbWrongAnswers.Location = new System.Drawing.Point(10, 328);
            this.lbWrongAnswers.Name = "lbWrongAnswers";
            this.lbWrongAnswers.Size = new System.Drawing.Size(66, 24);
            this.lbWrongAnswers.TabIndex = 5;
            this.lbWrongAnswers.Text = "label1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(91, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 37);
            this.label1.TabIndex = 6;
            this.label1.Text = "Game Over";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbType);
            this.panel1.Controls.Add(this.lbResult);
            this.panel1.Controls.Add(this.lbWrongAnswers);
            this.panel1.Controls.Add(this.lbNQ);
            this.panel1.Controls.Add(this.lbRightAnswers);
            this.panel1.Controls.Add(this.lbLevel);
            this.panel1.Location = new System.Drawing.Point(2, 100);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(370, 394);
            this.panel1.TabIndex = 7;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.simple_math_photo_powerpoint1;
            this.ClientSize = new System.Drawing.Size(373, 497);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbResult;
        private System.Windows.Forms.Label lbNQ;
        private System.Windows.Forms.Label lbLevel;
        private System.Windows.Forms.Label lbType;
        private System.Windows.Forms.Label lbRightAnswers;
        private System.Windows.Forms.Label lbWrongAnswers;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
    }
}