﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.rdMix = new System.Windows.Forms.RadioButton();
            this.rdHard = new System.Windows.Forms.RadioButton();
            this.rdMid = new System.Windows.Forms.RadioButton();
            this.rdEasy = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rdMiix = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.rdAdd = new System.Windows.Forms.RadioButton();
            this.rdDiv = new System.Windows.Forms.RadioButton();
            this.rdSub = new System.Windows.Forms.RadioButton();
            this.rdMul = new System.Windows.Forms.RadioButton();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.btStart = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Ravie", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(16, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(464, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "Welcome To Math Game";
            // 
            // rdMix
            // 
            this.rdMix.AutoSize = true;
            this.rdMix.BackColor = System.Drawing.Color.Transparent;
            this.rdMix.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdMix.Location = new System.Drawing.Point(271, 50);
            this.rdMix.Name = "rdMix";
            this.rdMix.Size = new System.Drawing.Size(58, 28);
            this.rdMix.TabIndex = 5;
            this.rdMix.TabStop = true;
            this.rdMix.Text = "Mix";
            this.rdMix.UseVisualStyleBackColor = false;
            this.rdMix.CheckedChanged += new System.EventHandler(this.rdMix_CheckedChanged);
            // 
            // rdHard
            // 
            this.rdHard.AutoSize = true;
            this.rdHard.BackColor = System.Drawing.Color.Transparent;
            this.rdHard.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdHard.Location = new System.Drawing.Point(178, 50);
            this.rdHard.Name = "rdHard";
            this.rdHard.Size = new System.Drawing.Size(69, 28);
            this.rdHard.TabIndex = 4;
            this.rdHard.TabStop = true;
            this.rdHard.Text = "Hard";
            this.rdHard.UseVisualStyleBackColor = false;
            this.rdHard.CheckedChanged += new System.EventHandler(this.rdHard_CheckedChanged);
            // 
            // rdMid
            // 
            this.rdMid.AutoSize = true;
            this.rdMid.BackColor = System.Drawing.Color.Transparent;
            this.rdMid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdMid.Location = new System.Drawing.Point(96, 50);
            this.rdMid.Name = "rdMid";
            this.rdMid.Size = new System.Drawing.Size(59, 28);
            this.rdMid.TabIndex = 3;
            this.rdMid.TabStop = true;
            this.rdMid.Text = "Mid";
            this.rdMid.UseVisualStyleBackColor = false;
            this.rdMid.CheckedChanged += new System.EventHandler(this.rdMid_CheckedChanged);
            // 
            // rdEasy
            // 
            this.rdEasy.AutoSize = true;
            this.rdEasy.BackColor = System.Drawing.Color.Transparent;
            this.rdEasy.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdEasy.Location = new System.Drawing.Point(1, 50);
            this.rdEasy.Name = "rdEasy";
            this.rdEasy.Size = new System.Drawing.Size(69, 28);
            this.rdEasy.TabIndex = 2;
            this.rdEasy.TabStop = true;
            this.rdEasy.Text = "Easy";
            this.rdEasy.UseVisualStyleBackColor = false;
            this.rdEasy.CheckedChanged += new System.EventHandler(this.rdEasy_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(7, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(332, 24);
            this.label3.TabIndex = 5;
            this.label3.Text = "How Many Questions To Answer ?";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.rdEasy);
            this.panel1.Controls.Add(this.rdMix);
            this.panel1.Controls.Add(this.rdMid);
            this.panel1.Controls.Add(this.rdHard);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(11, 261);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(336, 82);
            this.panel1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(224, 31);
            this.label2.TabIndex = 6;
            this.label2.Text = "Questions Level";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rdMiix);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.rdAdd);
            this.panel2.Controls.Add(this.rdDiv);
            this.panel2.Controls.Add(this.rdSub);
            this.panel2.Controls.Add(this.rdMul);
            this.panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(11, 380);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(403, 82);
            this.panel2.TabIndex = 6;
            // 
            // rdMiix
            // 
            this.rdMiix.AutoSize = true;
            this.rdMiix.BackColor = System.Drawing.Color.Transparent;
            this.rdMiix.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdMiix.Location = new System.Drawing.Point(339, 50);
            this.rdMiix.Name = "rdMiix";
            this.rdMiix.Size = new System.Drawing.Size(58, 28);
            this.rdMiix.TabIndex = 11;
            this.rdMiix.TabStop = true;
            this.rdMiix.Text = "Mix";
            this.rdMiix.UseVisualStyleBackColor = false;
            this.rdMiix.CheckedChanged += new System.EventHandler(this.rdMiix_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(3, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(219, 31);
            this.label4.TabIndex = 6;
            this.label4.Text = "Questions Type";
            // 
            // rdAdd
            // 
            this.rdAdd.AutoSize = true;
            this.rdAdd.BackColor = System.Drawing.Color.Transparent;
            this.rdAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdAdd.Location = new System.Drawing.Point(1, 50);
            this.rdAdd.Name = "rdAdd";
            this.rdAdd.Size = new System.Drawing.Size(63, 28);
            this.rdAdd.TabIndex = 7;
            this.rdAdd.TabStop = true;
            this.rdAdd.Text = "Add";
            this.rdAdd.UseVisualStyleBackColor = false;
            this.rdAdd.CheckedChanged += new System.EventHandler(this.rdAdd_CheckedChanged);
            // 
            // rdDiv
            // 
            this.rdDiv.AutoSize = true;
            this.rdDiv.BackColor = System.Drawing.Color.Transparent;
            this.rdDiv.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdDiv.Location = new System.Drawing.Point(260, 50);
            this.rdDiv.Name = "rdDiv";
            this.rdDiv.Size = new System.Drawing.Size(54, 28);
            this.rdDiv.TabIndex = 10;
            this.rdDiv.TabStop = true;
            this.rdDiv.Text = "Div";
            this.rdDiv.UseVisualStyleBackColor = false;
            this.rdDiv.CheckedChanged += new System.EventHandler(this.rdDiv_CheckedChanged);
            // 
            // rdSub
            // 
            this.rdSub.AutoSize = true;
            this.rdSub.BackColor = System.Drawing.Color.Transparent;
            this.rdSub.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdSub.Location = new System.Drawing.Point(89, 50);
            this.rdSub.Name = "rdSub";
            this.rdSub.Size = new System.Drawing.Size(62, 28);
            this.rdSub.TabIndex = 8;
            this.rdSub.TabStop = true;
            this.rdSub.Text = "Sub";
            this.rdSub.UseVisualStyleBackColor = false;
            this.rdSub.CheckedChanged += new System.EventHandler(this.rdSub_CheckedChanged);
            // 
            // rdMul
            // 
            this.rdMul.AutoSize = true;
            this.rdMul.BackColor = System.Drawing.Color.Transparent;
            this.rdMul.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdMul.Location = new System.Drawing.Point(176, 50);
            this.rdMul.Name = "rdMul";
            this.rdMul.Size = new System.Drawing.Size(59, 28);
            this.rdMul.TabIndex = 9;
            this.rdMul.TabStop = true;
            this.rdMul.Text = "Mul";
            this.rdMul.UseVisualStyleBackColor = false;
            this.rdMul.CheckedChanged += new System.EventHandler(this.rdMul_CheckedChanged);
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.BackColor = System.Drawing.Color.Black;
            this.maskedTextBox1.ForeColor = System.Drawing.Color.White;
            this.maskedTextBox1.Location = new System.Drawing.Point(12, 187);
            this.maskedTextBox1.Mask = "00000";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox1.TabIndex = 0;
            this.maskedTextBox1.ValidatingType = typeof(int);
            // 
            // btStart
            // 
            this.btStart.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btStart.ForeColor = System.Drawing.Color.White;
            this.btStart.Location = new System.Drawing.Point(178, 508);
            this.btStart.Name = "btStart";
            this.btStart.Size = new System.Drawing.Size(75, 23);
            this.btStart.TabIndex = 12;
            this.btStart.Text = "start";
            this.btStart.UseVisualStyleBackColor = true;
            this.btStart.Click += new System.EventHandler(this.btStart_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.simple_math_photo_powerpoint;
            this.ClientSize = new System.Drawing.Size(492, 540);
            this.Controls.Add(this.btStart);
            this.Controls.Add(this.maskedTextBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.Color.Crimson;
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rdMid;
        private System.Windows.Forms.RadioButton rdEasy;
        private System.Windows.Forms.RadioButton rdHard;
        private System.Windows.Forms.RadioButton rdMix;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton rdMiix;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton rdAdd;
        private System.Windows.Forms.RadioButton rdDiv;
        private System.Windows.Forms.RadioButton rdSub;
        private System.Windows.Forms.RadioButton rdMul;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.Button btStart;
    }
}

