﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static WindowsFormsApp1.Form1;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            panel1.BackColor=Color.FromArgb(125,Color.Black);
        }
       
        private Random random = new Random();
        private float N1, N2, Answer;
        private short QuestionNumber = 1;
        private bool done=false;
        private int RandLevel( )
        {
            int Rand = 0;
            switch (stGameDate.Level)
            {
                case enlevel.Mid:
                    Rand = random.Next(10,50);
                    break;
                case enlevel.Easy:
                    Rand = random.Next(1,10);
                    break;
                case enlevel.Hard:
                    Rand = random.Next(50,100);
                    break;
                case enlevel.Mix:
                    Rand = random.Next(1,100);
                    break;

            }
            return Rand;

        }
        private void AddNumbers( )
        {
            
            lbQuestion.Text = N1 + " + " + N2 + " = ";            
        }
 
      private  void DivNumbers()
        {
            lbQuestion.Text = N1 + " / " + N2+" = ";
            
        }

        private void SubNumbers()
        {
            lbQuestion.Text = N1 + " - " + N2 + " = ";

        }


        private void MulNumbers()
    {
            lbQuestion.Text = N1 + " * " + N2 + " = ";
             
    }
      public static  string NameLevel( )
        {
            string[] NameLevel = { "Easy", "Mid", "Hard", "Mix" };
            return NameLevel[Convert.ToInt16(Form1.stGameDate.Level) - 1];
        }
      public static  string NameType()
        {
            string[] NameLevel = { "+", "-", "*", "/", "Mix" };
            return NameLevel[Convert.ToInt16(Form1.stGameDate.Level) - 1];
        }
      
        private void Form2_Load(object sender, EventArgs e)
        {
            PlayGame();
            QuestionNumber++;
        }

        private void btCheck_Click(object sender, EventArgs e)
        {
            float UserAnswer = 0;

            if (done)
                return;

            switch (stGameDate.Type) {
                case enType.Add:
                    Answer = N1 + N2;
                   
                    break;
                case enType.Div:
                    Answer = N1 / N2;
                   
                    break;
                case enType.Mul:
                    Answer = N1 * N2;
                   
                    break;
                case enType.Sub:
                    Answer = N1 - N2;
                   
                    break;
            }
            if (maskedTextBox1.Text =="")
            {
                MessageBox.Show("Enter Your Answer", "message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
                
            else 
                UserAnswer = float.Parse(maskedTextBox1.Text);  

            if (Answer == UserAnswer)
            {
                lbResult.Text = "Right Answer ";

                stGameDate.RightAnswers++;
                lbRightAnswers.Text=stGameDate.RightAnswers.ToString();
            }
            else
            {
                lbResult.Text = "Wrong Answer  \nThe Right Answer is " + Answer;

                stGameDate.WrongAnsewrs++;
                lbWrongAnswers.Text=stGameDate.WrongAnsewrs.ToString();
            }
            done = true;

        }
        private void excuteOperation( )
        {
            switch (Form1.stGameDate.Type)
            {
                case enType.Add:
                     AddNumbers();
                    break;
                case enType.Div:
                     DivNumbers();
                    break;
                case enType.Mul:
                     MulNumbers();
                    break;
                case enType.Sub:
                     SubNumbers();
                    break;
            }

        }
        private void btNext_Click(object sender, EventArgs e)
        {
            lbResult.Text = "";

            PlayGame();

            if (QuestionNumber <= stGameDate.HowManyQuestions)
                QuestionNumber++;
            else
            {
                Form form = new Form3();
                form.ShowDialog();
            }
        }

       

        private void MixOperation( )
        {
            
                int N = 0;
                N = random.Next(1, 4);
                stGameDate.Type = (enType)N;
                excuteOperation();
               
           
        }
        private void PlayGame( )
        {
            
            
                lbQN.Text= "Question  [" + QuestionNumber + "/" + stGameDate.HowManyQuestions + "]" ;
                N1 = RandLevel();
                N2 = RandLevel();
                done = false;
                maskedTextBox1.Text = "";
            if (stGameDate.Type == Form1.enType.mix)
                {
                    MixOperation();
                   
                }
                excuteOperation();
        }
    }
}
