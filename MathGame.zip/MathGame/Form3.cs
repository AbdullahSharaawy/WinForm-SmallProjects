﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            panel1.BackColor = Color.FromArgb(125, Color.Black);

            if (Form1.stGameDate.RightAnswers > Form1.stGameDate.WrongAnsewrs) { lbResult.Text= "Final Results is Victory "; }
            else if (Form1.stGameDate.RightAnswers < Form1.stGameDate.WrongAnsewrs) { lbResult.Text = "Final Results is Fail "; }
            else { lbResult.Text= "Final Results is Draw "; }
            lbNQ.Text= "Number of Questions : " + Form1.stGameDate.HowManyQuestions ;
            lbLevel.Text= "Question Level      : " +Form2.NameLevel() ;
            lbType.Text= "Operation Type      : " + Form2.NameType();
            lbRightAnswers.Text= "Number of Right Answers : " + Form1.stGameDate.RightAnswers ;
            lbWrongAnswers.Text= "Number of Wrong Answers : " + Form1.stGameDate.WrongAnsewrs ;
        }
    }
}
