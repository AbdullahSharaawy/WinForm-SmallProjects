﻿namespace WindowsFormsApp1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbQN = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btNext = new System.Windows.Forms.Button();
            this.btCheck = new System.Windows.Forms.Button();
            this.lbResult = new System.Windows.Forms.Label();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.lbQuestion = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbWrongAnswers = new System.Windows.Forms.Label();
            this.lbRightAnswers = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbQN
            // 
            this.lbQN.AutoSize = true;
            this.lbQN.BackColor = System.Drawing.Color.Transparent;
            this.lbQN.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbQN.ForeColor = System.Drawing.Color.Black;
            this.lbQN.Location = new System.Drawing.Point(172, 26);
            this.lbQN.Name = "lbQN";
            this.lbQN.Size = new System.Drawing.Size(0, 31);
            this.lbQN.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btNext);
            this.panel1.Controls.Add(this.btCheck);
            this.panel1.Controls.Add(this.lbResult);
            this.panel1.Controls.Add(this.maskedTextBox1);
            this.panel1.Controls.Add(this.lbQuestion);
            this.panel1.Location = new System.Drawing.Point(80, 116);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(405, 312);
            this.panel1.TabIndex = 2;
            // 
            // btNext
            // 
            this.btNext.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btNext.Location = new System.Drawing.Point(288, 262);
            this.btNext.Name = "btNext";
            this.btNext.Size = new System.Drawing.Size(104, 33);
            this.btNext.TabIndex = 4;
            this.btNext.Text = "Next";
            this.btNext.UseVisualStyleBackColor = false;
            this.btNext.Click += new System.EventHandler(this.btNext_Click);
            // 
            // btCheck
            // 
            this.btCheck.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btCheck.Location = new System.Drawing.Point(9, 262);
            this.btCheck.Name = "btCheck";
            this.btCheck.Size = new System.Drawing.Size(104, 33);
            this.btCheck.TabIndex = 3;
            this.btCheck.Text = "Check";
            this.btCheck.UseVisualStyleBackColor = false;
            this.btCheck.Click += new System.EventHandler(this.btCheck_Click);
            // 
            // lbResult
            // 
            this.lbResult.AutoSize = true;
            this.lbResult.BackColor = System.Drawing.Color.Transparent;
            this.lbResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbResult.ForeColor = System.Drawing.Color.Red;
            this.lbResult.Location = new System.Drawing.Point(13, 154);
            this.lbResult.Name = "lbResult";
            this.lbResult.Size = new System.Drawing.Size(0, 29);
            this.lbResult.TabIndex = 2;
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBox1.Location = new System.Drawing.Point(92, 68);
            this.maskedTextBox1.Mask = "00000";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(218, 31);
            this.maskedTextBox1.TabIndex = 1;
            this.maskedTextBox1.ValidatingType = typeof(int);
            // 
            // lbQuestion
            // 
            this.lbQuestion.AutoSize = true;
            this.lbQuestion.BackColor = System.Drawing.Color.Transparent;
            this.lbQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbQuestion.Location = new System.Drawing.Point(97, 19);
            this.lbQuestion.Name = "lbQuestion";
            this.lbQuestion.Size = new System.Drawing.Size(0, 31);
            this.lbQuestion.TabIndex = 0;
          
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::WindowsFormsApp1.Properties.Resources._true;
            this.pictureBox2.Location = new System.Drawing.Point(12, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(69, 54);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
           
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApp1.Properties.Resources._false;
            this.pictureBox1.Location = new System.Drawing.Point(493, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(69, 54);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // lbWrongAnswers
            // 
            this.lbWrongAnswers.AutoSize = true;
            this.lbWrongAnswers.BackColor = System.Drawing.Color.Transparent;
            this.lbWrongAnswers.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbWrongAnswers.ForeColor = System.Drawing.Color.Black;
            this.lbWrongAnswers.Location = new System.Drawing.Point(509, 74);
            this.lbWrongAnswers.Name = "lbWrongAnswers";
            this.lbWrongAnswers.Size = new System.Drawing.Size(0, 31);
            this.lbWrongAnswers.TabIndex = 6;
            // 
            // lbRightAnswers
            // 
            this.lbRightAnswers.AutoSize = true;
            this.lbRightAnswers.BackColor = System.Drawing.Color.Transparent;
            this.lbRightAnswers.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRightAnswers.ForeColor = System.Drawing.Color.Black;
            this.lbRightAnswers.Location = new System.Drawing.Point(32, 73);
            this.lbRightAnswers.Name = "lbRightAnswers";
            this.lbRightAnswers.Size = new System.Drawing.Size(0, 31);
            this.lbRightAnswers.TabIndex = 7;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.mathgameBackGround;
            this.ClientSize = new System.Drawing.Size(574, 450);
            this.Controls.Add(this.lbRightAnswers);
            this.Controls.Add(this.lbWrongAnswers);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lbQN);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lbQN;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbQuestion;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.Label lbResult;
        private System.Windows.Forms.Button btNext;
        private System.Windows.Forms.Button btCheck;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbWrongAnswers;
        private System.Windows.Forms.Label lbRightAnswers;
    }
}