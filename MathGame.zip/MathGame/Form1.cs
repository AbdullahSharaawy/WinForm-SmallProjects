﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            panel1.BackColor=Color.FromArgb(125,Color.Black);

            panel2.BackColor = Color.FromArgb(125, Color.Black);

            btStart.BackColor = Color.FromArgb(125, Color.Black);

        }
        public enum enlevel { Easy = 1, Mid = 2, Hard = 3, Mix = 4 };
        public enum enType { Add = 1, Sub = 2, Mul = 3, Div = 4, mix = 5 };
        public struct GameDate
        {
            public int HowManyQuestions;
            public enlevel Level;
            public enType Type;
            public int RightAnswers;
            public int WrongAnsewrs;
        };

        public static GameDate stGameDate= new GameDate();
        
        private void rdMid_CheckedChanged(object sender, EventArgs e)
        {
            stGameDate.Level = enlevel.Mid;
        }

        private void rdEasy_CheckedChanged(object sender, EventArgs e)
        {
            stGameDate.Level = enlevel.Easy;
        }

        private void rdHard_CheckedChanged(object sender, EventArgs e)
        {
            stGameDate.Level = enlevel.Hard;
        }

        private void rdMix_CheckedChanged(object sender, EventArgs e)
        {
            stGameDate.Level = enlevel.Mix;
        }

        private void rdAdd_CheckedChanged(object sender, EventArgs e)
        {
            stGameDate.Type = enType.Add;
        }

        private void rdSub_CheckedChanged(object sender, EventArgs e)
        {
            stGameDate.Type = enType.Sub;
        }

        private void rdMul_CheckedChanged(object sender, EventArgs e)
        {
            stGameDate.Type = enType.Mul;
        }

        private void rdDiv_CheckedChanged(object sender, EventArgs e)
        {
            stGameDate.Type = enType.Div;
        }

        private void rdMiix_CheckedChanged(object sender, EventArgs e)
        {
            stGameDate.Type = enType.mix;
        }

        private void btStart_Click(object sender, EventArgs e)
        {
            if(maskedTextBox1.Text.Length==0)
            {
                MessageBox.Show("Enter Number of Questions! ","Message",MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                stGameDate.HowManyQuestions = Convert.ToInt16(maskedTextBox1.Text);
                Form form = new Form2();
                form.ShowDialog();
            }
            
        }
    }
}
